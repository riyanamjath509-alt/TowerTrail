import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                JFrame f = new JFrame("Tower Trail");
                f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                GamePanel panel = new GamePanel();
                f.setContentPane(panel);
                f.setResizable(false);
                f.pack();
                f.setLocationRelativeTo(null);
                f.setVisible(true);
                panel.requestFocusInWindow();
                panel.start();
            }
        });
    }
}
