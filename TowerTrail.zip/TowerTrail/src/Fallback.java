import java.awt.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;

/**
 * Built-in drawn "skins" for the hero, bosses and minions.
 * Used automatically when an image file can't be found, so you never see a pink box.
 */
public class Fallback {
    static final Color INK = new Color(28, 20, 30);
    static final Color GOLD = new Color(232, 188, 70);

    public static BufferedImage make(String file) {
        String n = file.substring(0, file.lastIndexOf('.'));
        if (n.equals("title")) return title();
        if (n.startsWith("player_")) return hero(n);
        return monster(n);
    }

    private static BufferedImage canvas(int w, int h) {
        return new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
    }

    private static Graphics2D gfx(BufferedImage im) {
        Graphics2D g = im.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        return g;
    }

    private static void outline(Graphics2D g, Shape s, Color fill, float lw) {
        g.setColor(fill);
        g.fill(s);
        g.setColor(INK);
        g.setStroke(new BasicStroke(lw, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.draw(s);
    }

    private static Color dark(Color c) {
        return new Color(c.getRed() * 6 / 10, c.getGreen() * 6 / 10, c.getBlue() * 6 / 10);
    }

    // ------------------------------------------------------------------ title
    private static BufferedImage title() {
        BufferedImage im = canvas(960, 640);
        Graphics2D g = gfx(im);
        g.setPaint(new GradientPaint(0, 0, new Color(90, 150, 225), 0, 640, new Color(200, 230, 190)));
        g.fillRect(0, 0, 960, 640);
        g.setColor(new Color(90, 130, 120));
        Path2D.Double m = new Path2D.Double();
        m.moveTo(0, 520);
        for (int x = 0; x <= 960; x += 80) m.lineTo(x, 330 + (x * 37 % 130));
        m.lineTo(960, 520);
        g.fill(m);
        g.setColor(new Color(70, 120, 60));
        g.fillRect(0, 540, 960, 100);
        for (int i = 0; i < 7; i++) {
            int w = 300 - i * 34, y = 520 - i * 60;
            outline(g, new Rectangle2D.Double(480 - w / 2.0, y - 60, w, 60), new Color(120 + i * 6, 118 + i * 6, 104 + i * 6), 3f);
            g.setColor(new Color(60, 110, 50, 160));
            g.fillRect(480 - w / 2, y - 60, w, 8);
        }
        outline(g, new RoundRectangle2D.Double(450, 450, 60, 70, 20, 20), new Color(40, 28, 20), 3f);
        g.setFont(new Font("Serif", Font.BOLD, 96));
        String t = "TOWER TRAIL";
        int tw = g.getFontMetrics().stringWidth(t);
        g.setColor(INK);
        g.drawString(t, 480 - tw / 2 + 4, 124);
        g.setColor(new Color(214, 190, 120));
        g.drawString(t, 480 - tw / 2, 120);
        g.dispose();
        return im;
    }

    // ------------------------------------------------------------------ hero
    private static BufferedImage hero(String n) {
        int w = 90, h = 160;
        if (n.equals("player_idle")) { w = 76; h = 160; }
        else if (n.equals("player_walk")) { w = 89; h = 160; }
        else if (n.equals("player_run")) { w = 99; h = 134; }
        else if (n.equals("player_jump")) { w = 101; h = 151; }
        else if (n.equals("player_fall")) { w = 83; h = 147; }
        else if (n.equals("player_attack")) { w = 303; h = 272; }
        else if (n.equals("player_front")) { w = 228; h = 420; }
        else { w = 170; h = 200; }
        BufferedImage im = canvas(w, h);
        Graphics2D g = gfx(im);
        boolean face = n.equals("player_portrait") || n.equals("player_happy")
                || n.equals("player_angry") || n.equals("player_surprised");
        if (face) face(g, w, h, n);
        else body(g, w, h, n);
        g.dispose();
        return im;
    }

    private static void face(Graphics2D g, int w, int h, String n) {
        Color green = new Color(60, 100, 56), skin = new Color(240, 200, 165), hair = new Color(48, 32, 24);
        outline(g, new Ellipse2D.Double(-w * 0.1, h * 0.66, w * 1.2, h * 0.6), green, 3f);
        outline(g, new Ellipse2D.Double(w * 0.08, h * 0.04, w * 0.84, h * 0.74), hair, 3f);
        outline(g, new Ellipse2D.Double(w * 0.2, h * 0.2, w * 0.6, h * 0.58), skin, 3f);
        Path2D.Double fringe = new Path2D.Double();
        fringe.moveTo(w * 0.18, h * 0.34);
        fringe.lineTo(w * 0.3, h * 0.12);
        fringe.lineTo(w * 0.42, h * 0.3);
        fringe.lineTo(w * 0.52, h * 0.1);
        fringe.lineTo(w * 0.62, h * 0.3);
        fringe.lineTo(w * 0.78, h * 0.14);
        fringe.lineTo(w * 0.84, h * 0.36);
        fringe.closePath();
        outline(g, fringe, hair, 2f);
        double ey = h * 0.46;
        g.setStroke(new BasicStroke(4f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.setColor(INK);
        if (n.equals("player_happy")) {
            g.draw(new Arc2D.Double(w * 0.3, ey - 6, w * 0.14, 14, 0, 180, Arc2D.OPEN));
            g.draw(new Arc2D.Double(w * 0.56, ey - 6, w * 0.14, 14, 0, 180, Arc2D.OPEN));
            g.setColor(new Color(150, 40, 50));
            g.fill(new Arc2D.Double(w * 0.38, h * 0.58, w * 0.24, h * 0.14, 180, 180, Arc2D.CHORD));
        } else if (n.equals("player_surprised")) {
            g.setColor(Color.WHITE);
            g.fill(new Ellipse2D.Double(w * 0.3, ey - 10, w * 0.15, 22));
            g.fill(new Ellipse2D.Double(w * 0.55, ey - 10, w * 0.15, 22));
            g.setColor(INK);
            g.fill(new Ellipse2D.Double(w * 0.35, ey - 3, 7, 10));
            g.fill(new Ellipse2D.Double(w * 0.6, ey - 3, 7, 10));
            g.fill(new Ellipse2D.Double(w * 0.44, h * 0.6, w * 0.12, h * 0.1));
        } else {
            g.fill(new Ellipse2D.Double(w * 0.33, ey - 6, 10, 14));
            g.fill(new Ellipse2D.Double(w * 0.6, ey - 6, 10, 14));
            if (n.equals("player_angry")) {
                g.draw(new Line2D.Double(w * 0.28, ey - 16, w * 0.46, ey - 8));
                g.draw(new Line2D.Double(w * 0.72, ey - 16, w * 0.54, ey - 8));
                g.draw(new Line2D.Double(w * 0.4, h * 0.64, w * 0.6, h * 0.62));
            } else {
                g.draw(new Line2D.Double(w * 0.42, h * 0.63, w * 0.58, h * 0.63));
            }
        }
    }

    private static void body(Graphics2D g, int w, int h, String n) {
        Color green = new Color(62, 104, 58), skin = new Color(240, 200, 165), hair = new Color(48, 32, 24),
                pants = new Color(80, 56, 40), boots = new Color(110, 72, 44), shirt = new Color(235, 228, 205);
        boolean atk = n.equals("player_attack");
        double cx = atk ? w * 0.4 : w * 0.5;
        double u = atk ? h * 0.9 : h; // body scale
        double top = atk ? h * 0.06 : 0;
        double headR = u * 0.105;
        double hx = cx + (atk ? w * 0.03 : 0), hy = top + u * 0.13;
        boolean air = n.equals("player_jump") || n.equals("player_fall");
        boolean walk = n.equals("player_walk") || n.equals("player_run");
        // cape trailing behind (left)
        Path2D.Double cape = new Path2D.Double();
        cape.moveTo(cx - w * 0.05, top + u * 0.26);
        cape.lineTo(cx - w * (atk ? 0.3 : 0.38), top + u * (air ? 0.62 : 0.78));
        cape.lineTo(cx + w * 0.02, top + u * 0.66);
        cape.closePath();
        outline(g, cape, green, 3f);
        // sword hilt on back
        g.setColor(new Color(120, 120, 130));
        g.setStroke(new BasicStroke(5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.draw(new Line2D.Double(cx - w * 0.12, top + u * 0.3, cx - w * 0.2, top + u * 0.12));
        // legs
        double ly = top + u * 0.6, lh = u * (air ? 0.22 : 0.34);
        double spread = atk ? w * 0.2 : (walk ? w * 0.14 : w * 0.06);
        outline(g, new RoundRectangle2D.Double(cx - w * 0.1 - spread, ly, w * 0.13, lh, 6, 6), pants, 3f);
        outline(g, new RoundRectangle2D.Double(cx + w * 0.0 + spread, ly, w * 0.13, lh, 6, 6), pants, 3f);
        outline(g, new RoundRectangle2D.Double(cx - w * 0.12 - spread, ly + lh - 8, w * 0.17, 14, 6, 6), boots, 3f);
        outline(g, new RoundRectangle2D.Double(cx - w * 0.01 + spread, ly + lh - 8, w * 0.17, 14, 6, 6), boots, 3f);
        // torso
        outline(g, new RoundRectangle2D.Double(cx - w * 0.14, top + u * 0.26, w * 0.28, u * 0.38, 12, 12), shirt, 3f);
        g.setColor(boots);
        g.fill(new Rectangle2D.Double(cx - w * 0.14, top + u * 0.52, w * 0.28, 7));
        // arm + sword
        g.setColor(INK);
        if (atk) {
            g.setStroke(new BasicStroke(9f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g.setColor(new Color(235, 240, 250));
            g.draw(new Line2D.Double(cx + w * 0.08, top + u * 0.46, w * 0.97, top + u * 0.4));
            g.setColor(INK);
            g.setStroke(new BasicStroke(2f));
            g.draw(new Line2D.Double(cx + w * 0.08, top + u * 0.43, w * 0.97, top + u * 0.37));
            g.setColor(GOLD);
            g.setStroke(new BasicStroke(6f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g.draw(new Line2D.Double(cx + w * 0.1, top + u * 0.38, cx + w * 0.12, top + u * 0.54));
        }
        g.setColor(skin);
        g.setStroke(new BasicStroke(7f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.draw(new Line2D.Double(cx + w * 0.1, top + u * 0.32, cx + w * (atk ? 0.12 : 0.16), top + u * (atk ? 0.46 : 0.5)));
        // head
        outline(g, new Ellipse2D.Double(hx - headR, hy - headR, headR * 2, headR * 2), skin, 3f);
        Path2D.Double hairP = new Path2D.Double();
        hairP.moveTo(hx - headR * 1.1, hy - headR * 0.1);
        hairP.lineTo(hx - headR * 0.8, hy - headR * 1.25);
        hairP.lineTo(hx - headR * 0.2, hy - headR * 0.8);
        hairP.lineTo(hx + headR * 0.3, hy - headR * 1.35);
        hairP.lineTo(hx + headR * 0.9, hy - headR * 0.7);
        hairP.lineTo(hx + headR * 1.1, hy - headR * 0.05);
        hairP.lineTo(hx + headR * 0.2, hy - headR * 0.4);
        hairP.closePath();
        outline(g, hairP, hair, 2f);
        g.setColor(INK);
        g.fill(new Ellipse2D.Double(hx + headR * 0.25, hy - headR * 0.1, headR * 0.28, headR * 0.4));
        // hood
        g.setColor(green);
        g.setStroke(new BasicStroke(8f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.draw(new Line2D.Double(cx - w * 0.12, top + u * 0.27, cx + w * 0.12, top + u * 0.27));
    }

    // ------------------------------------------------------------------ monsters
    private static BufferedImage monster(String n) {
        boolean atk = n.endsWith("_atk");
        String b = atk ? n.substring(0, n.length() - 4) : n;
        int w = 300, h = 260;
        String kind = "beast";
        Color c1 = new Color(110, 120, 60), c2 = new Color(70, 60, 40), eye = new Color(255, 230, 60);
        if (b.equals("boss1")) { w = 564; h = 520; kind = "beast"; }
        else if (b.equals("boss2")) { w = 499; h = 560; kind = "book"; c1 = new Color(80, 50, 130); c2 = GOLD; eye = new Color(190, 120, 255); }
        else if (b.equals("boss3")) { w = 564; h = 560; kind = "tree"; c1 = new Color(100, 70, 40); c2 = new Color(70, 130, 50); eye = new Color(255, 150, 30); }
        else if (b.equals("boss4")) { w = 536; h = 560; kind = "tentacle"; c1 = new Color(70, 100, 70); c2 = new Color(40, 120, 100); eye = new Color(120, 255, 130); }
        else if (b.equals("boss5")) { w = 349; h = 420; kind = "dragon"; c1 = new Color(40, 36, 44); c2 = new Color(190, 40, 30); eye = new Color(255, 170, 40); }
        else if (b.equals("m1a")) { w = 359; kind = "beast"; }
        else if (b.equals("m2a")) { w = 267; kind = "book"; c1 = new Color(40, 90, 150); c2 = new Color(150, 220, 255); eye = new Color(170, 240, 255); }
        else if (b.equals("m2b")) { w = 266; kind = "book"; c1 = new Color(150, 40, 40); c2 = GOLD; eye = new Color(255, 190, 40); }
        else if (b.equals("m3a")) { w = 292; kind = "bush"; c1 = new Color(70, 120, 50); c2 = new Color(110, 80, 40); eye = new Color(255, 190, 40); }
        else if (b.equals("m3b")) { w = 210; kind = "flower"; c1 = new Color(200, 60, 160); c2 = new Color(70, 130, 50); eye = new Color(255, 210, 60); }
        else if (b.equals("m3c")) { w = 216; kind = "tree"; c1 = new Color(110, 80, 44); c2 = new Color(80, 130, 56); eye = new Color(255, 170, 40); }
        else if (b.equals("m4a") || b.equals("m4c")) { w = b.equals("m4a") ? 285 : 209; kind = "tentacle"; c1 = new Color(60, 96, 74); c2 = new Color(50, 150, 120); eye = new Color(120, 255, 140); }
        else if (b.equals("m4b")) { w = 313; kind = "tentacle"; c1 = new Color(60, 110, 80); c2 = new Color(60, 170, 120); eye = new Color(140, 255, 160); }
        else if (b.equals("m5a")) { w = 252; kind = "serpent"; c1 = new Color(30, 90, 150); c2 = new Color(110, 220, 255); eye = new Color(255, 255, 120); }
        else if (b.equals("m5b")) { w = 236; kind = "serpent"; c1 = new Color(60, 40, 60); c2 = new Color(230, 110, 40); eye = new Color(255, 120, 60); }
        else if (b.equals("m5c")) { w = 275; kind = "beast"; c1 = new Color(150, 40, 40); c2 = new Color(60, 30, 30); eye = new Color(255, 220, 60); }
        else if (b.equals("m5d")) { w = 256; kind = "serpent"; c1 = new Color(40, 50, 140); c2 = new Color(150, 130, 255); eye = new Color(255, 120, 255); }
        if (atk) w = (int) (w * 1.4);
        BufferedImage im = canvas(w, h);
        Graphics2D g = gfx(im);
        int ox = atk ? (int) (w * 0.12) : 0;
        g.translate(ox, 0);
        int dw = atk ? (int) (w / 1.4) : w;
        if (kind.equals("beast")) beast(g, dw, h, c1, c2, eye);
        else if (kind.equals("book")) book(g, dw, h, c1, c2, eye);
        else if (kind.equals("tree")) tree(g, dw, h, c1, c2, eye);
        else if (kind.equals("bush")) bush(g, dw, h, c1, c2, eye);
        else if (kind.equals("flower")) flower(g, dw, h, c1, c2, eye);
        else if (kind.equals("tentacle")) tentacle(g, dw, h, c1, c2, eye);
        else if (kind.equals("serpent")) serpent(g, dw, h, c1, c2, eye);
        else dragon(g, dw, h, c1, c2, eye);
        g.translate(-ox, 0);
        if (atk) { // motion streaks
            g.setStroke(new BasicStroke(h * 0.03f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            for (int i = 0; i < 3; i++) {
                g.setColor(new Color(255, 255, 255, 170 - i * 40));
                g.draw(new Arc2D.Double(w * (0.62 + i * 0.04), h * (0.15 + i * 0.05), w * 0.3, h * (0.7 - i * 0.1), -70, 140, Arc2D.OPEN));
            }
        }
        g.dispose();
        return im;
    }

    private static void eyes(Graphics2D g, double x, double y, double s, Color eye, boolean angry) {
        for (int i = -1; i <= 1; i += 2) {
            double ex = x + i * s * 0.9;
            g.setColor(new Color(eye.getRed(), eye.getGreen(), eye.getBlue(), 90));
            g.fill(new Ellipse2D.Double(ex - s * 0.7, y - s * 0.7, s * 1.4, s * 1.4));
            g.setColor(eye);
            g.fill(new Ellipse2D.Double(ex - s * 0.45, y - s * 0.3, s * 0.9, s * 0.6));
            g.setColor(INK);
            g.fill(new Ellipse2D.Double(ex - s * 0.1, y - s * 0.28, s * 0.2, s * 0.56));
            if (angry) {
                g.setStroke(new BasicStroke((float) (s * 0.25), BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                g.draw(new Line2D.Double(ex - i * s * 0.6, y - s * 0.75 + i * s * 0.0, ex + i * s * 0.5, y - s * 0.3));
            }
        }
    }

    private static void teeth(Graphics2D g, double x, double y, double wd, double ht) {
        Path2D.Double mouth = new Path2D.Double();
        mouth.moveTo(x - wd / 2, y);
        int n = 6;
        for (int i = 0; i < n; i++) {
            mouth.lineTo(x - wd / 2 + wd * (i + 0.5) / n, y + (i % 2 == 0 ? ht : 0));
            mouth.lineTo(x - wd / 2 + wd * (i + 1) / n, y);
        }
        mouth.closePath();
        outline(g, mouth, new Color(240, 235, 215), 2f);
    }

    private static void beast(Graphics2D g, int w, int h, Color c1, Color c2, Color eye) {
        g.setStroke(new BasicStroke(h * 0.07f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.setColor(c2);
        Path2D.Double tail = new Path2D.Double();
        tail.moveTo(w * 0.78, h * 0.55);
        tail.curveTo(w * 0.98, h * 0.5, w * 0.98, h * 0.2, w * 0.86, h * 0.1);
        g.draw(tail);
        for (int i = 0; i < 4; i++) {
            double lx = w * (i < 2 ? 0.25 + i * 0.1 : 0.58 + (i - 2) * 0.1);
            outline(g, new RoundRectangle2D.Double(lx, h * 0.62, w * 0.075, h * 0.36, 14, 14), i % 2 == 0 ? c1 : dark(c1), 3f);
        }
        outline(g, new Ellipse2D.Double(w * 0.2, h * 0.3, w * 0.62, h * 0.42), c1, 4f);
        g.setColor(dark(c1));
        for (int i = 0; i < 5; i++) g.fill(new Ellipse2D.Double(w * (0.35 + i * 0.09), h * (0.33 + (i % 2) * 0.05), w * 0.06, h * 0.06));
        double hx = w * 0.22, hy = h * 0.42, r = h * 0.2;
        for (int i = -1; i <= 1; i += 2) {
            Path2D.Double ear = new Path2D.Double();
            ear.moveTo(hx + i * r * 0.9, hy - r * 0.5);
            ear.lineTo(hx + i * r * 0.7, hy - r * 1.55);
            ear.lineTo(hx + i * r * 0.1, hy - r * 0.9);
            ear.closePath();
            outline(g, ear, c2, 3f);
        }
        outline(g, new Ellipse2D.Double(hx - r, hy - r * 0.85, r * 2, r * 1.8), c1, 4f);
        eyes(g, hx, hy - r * 0.15, r * 0.3, eye, true);
        teeth(g, hx, hy + r * 0.45, r * 0.9, r * 0.28);
    }

    private static void book(Graphics2D g, int w, int h, Color c1, Color c2, Color eye) {
        g.setColor(c2);
        g.setStroke(new BasicStroke(h * 0.035f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        for (int i = -1; i <= 1; i += 2) {
            Path2D.Double arm = new Path2D.Double();
            arm.moveTo(w * 0.5 + i * w * 0.27, h * 0.4);
            arm.curveTo(w * 0.5 + i * w * 0.45, h * 0.45, w * 0.5 + i * w * 0.48, h * 0.6, w * 0.5 + i * w * 0.4, h * 0.75);
            g.draw(arm);
            g.draw(new Line2D.Double(w * 0.5 + i * w * 0.14, h * 0.7, w * 0.5 + i * w * 0.16, h * 0.97));
        }
        outline(g, new RoundRectangle2D.Double(w * 0.22, h * 0.1, w * 0.56, h * 0.62, 24, 24), c1, 5f);
        g.setColor(c2);
        g.setStroke(new BasicStroke(h * 0.02f));
        g.draw(new RoundRectangle2D.Double(w * 0.26, h * 0.14, w * 0.48, h * 0.54, 16, 16));
        for (int i = 0; i < 4; i++) g.fill(new Rectangle2D.Double(w * 0.22, h * (0.16 + i * 0.14), w * 0.035, h * 0.06));
        Path2D.Double crown = new Path2D.Double();
        crown.moveTo(w * 0.38, h * 0.12);
        crown.lineTo(w * 0.42, h * 0.0);
        crown.lineTo(w * 0.5, h * 0.08);
        crown.lineTo(w * 0.58, h * 0.0);
        crown.lineTo(w * 0.62, h * 0.12);
        crown.closePath();
        outline(g, crown, GOLD, 3f);
        eyes(g, w * 0.5, h * 0.33, w * 0.07, eye, true);
        teeth(g, w * 0.5, h * 0.5, w * 0.34, h * 0.09);
    }

    private static void tree(Graphics2D g, int w, int h, Color c1, Color c2, Color eye) {
        for (int i = 0; i < 5; i++) {
            Path2D.Double root = new Path2D.Double();
            root.moveTo(w * (0.4 + i * 0.05), h * 0.8);
            root.curveTo(w * (0.2 + i * 0.15), h * 0.95, w * (0.1 + i * 0.2), h * 0.97, w * (0.05 + i * 0.22), h * 0.99);
            g.setColor(dark(c1));
            g.setStroke(new BasicStroke(h * 0.045f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g.draw(root);
        }
        for (int i = -1; i <= 1; i += 2) {
            Path2D.Double arm = new Path2D.Double();
            arm.moveTo(w * 0.5 + i * w * 0.15, h * 0.4);
            arm.curveTo(w * 0.5 + i * w * 0.4, h * 0.45, w * 0.5 + i * w * 0.5, h * 0.3, w * 0.5 + i * w * 0.42, h * 0.12);
            g.setColor(c1);
            g.setStroke(new BasicStroke(h * 0.05f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g.draw(arm);
        }
        outline(g, new RoundRectangle2D.Double(w * 0.3, h * 0.28, w * 0.4, h * 0.62, 40, 40), c1, 4f);
        for (int i = 0; i < 5; i++) {
            double cx = w * (0.25 + i * 0.125), cy = h * (0.2 + (i % 2) * 0.05);
            outline(g, new Ellipse2D.Double(cx - w * 0.14, cy - h * 0.14, w * 0.28, h * 0.28), i % 2 == 0 ? c2 : c2.darker(), 3f);
        }
        g.setColor(new Color(eye.getRed(), eye.getGreen(), eye.getBlue(), 90));
        g.fill(new Ellipse2D.Double(w * 0.36, h * 0.38, w * 0.28, h * 0.22));
        outline(g, new Ellipse2D.Double(w * 0.42, h * 0.4, w * 0.16, h * 0.18), eye, 3f);
        g.setColor(INK);
        g.fill(new Ellipse2D.Double(w * 0.49, h * 0.41, w * 0.025, h * 0.16));
    }

    private static void bush(Graphics2D g, int w, int h, Color c1, Color c2, Color eye) {
        g.setColor(c2);
        g.setStroke(new BasicStroke(h * 0.04f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.draw(new Line2D.Double(w * 0.12, h * 0.05, w * 0.18, h * 0.98));
        Path2D.Double blob = new Path2D.Double();
        blob.moveTo(w * 0.3, h * 0.95);
        for (int i = 0; i <= 12; i++) {
            double a = Math.PI + Math.PI * i / 12.0;
            double r = 0.34 + 0.06 * (i % 2);
            blob.lineTo(w * 0.6 + Math.cos(a) * w * r, h * 0.62 + Math.sin(a) * h * (r + 0.1));
        }
        blob.lineTo(w * 0.9, h * 0.95);
        blob.closePath();
        outline(g, blob, c1, 4f);
        eyes(g, w * 0.6, h * 0.5, w * 0.05, eye, true);
        teeth(g, w * 0.6, h * 0.66, w * 0.22, h * 0.07);
    }

    private static void flower(Graphics2D g, int w, int h, Color c1, Color c2, Color eye) {
        g.setColor(c2);
        g.setStroke(new BasicStroke(h * 0.05f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.draw(new Line2D.Double(w * 0.5, h * 0.5, w * 0.5, h * 0.88));
        g.draw(new Line2D.Double(w * 0.5, h * 0.88, w * 0.35, h * 0.99));
        g.draw(new Line2D.Double(w * 0.5, h * 0.88, w * 0.65, h * 0.99));
        for (int i = 0; i < 8; i++) {
            double a = Math.PI * 2 * i / 8;
            AffineTransform t = g.getTransform();
            g.translate(w * 0.5, h * 0.3);
            g.rotate(a);
            outline(g, new Ellipse2D.Double(-w * 0.09, -h * 0.3, w * 0.18, h * 0.24), i % 2 == 0 ? c1 : c1.brighter(), 3f);
            g.setTransform(t);
        }
        outline(g, new Ellipse2D.Double(w * 0.35, h * 0.2, w * 0.3, h * 0.2), eye, 3f);
        g.setColor(INK);
        g.fill(new Ellipse2D.Double(w * 0.47, h * 0.22, w * 0.06, h * 0.16));
    }

    private static void tentacle(Graphics2D g, int w, int h, Color c1, Color c2, Color eye) {
        for (int i = 0; i < 7; i++) {
            Path2D.Double t = new Path2D.Double();
            double sx = w * (0.3 + i * 0.07);
            t.moveTo(sx, h * 0.55);
            double dir = (i - 3) * 0.1;
            t.curveTo(sx + w * dir * 2, h * 0.75, sx - w * dir * 3, h * 0.85, sx + w * dir * 4, h * 0.98);
            g.setColor(i % 2 == 0 ? c2 : dark(c2));
            g.setStroke(new BasicStroke(h * 0.05f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g.draw(t);
        }
        outline(g, new RoundRectangle2D.Double(w * 0.28, h * 0.25, w * 0.44, h * 0.42, 30, 30), c1, 4f);
        g.setColor(c2);
        g.fill(new Rectangle2D.Double(w * 0.3, h * 0.42, w * 0.4, h * 0.05));
        Path2D.Double head = new Path2D.Double();
        head.moveTo(w * 0.34, h * 0.28);
        head.lineTo(w * 0.4, h * 0.06);
        head.lineTo(w * 0.5, h * 0.12);
        head.lineTo(w * 0.6, h * 0.06);
        head.lineTo(w * 0.66, h * 0.28);
        head.closePath();
        outline(g, head, dark(c1), 3f);
        g.setColor(new Color(eye.getRed(), eye.getGreen(), eye.getBlue(), 100));
        g.fill(new Ellipse2D.Double(w * 0.4, h * 0.1, w * 0.2, h * 0.17));
        g.setColor(eye);
        g.fill(new Ellipse2D.Double(w * 0.45, h * 0.14, w * 0.1, h * 0.1));
        g.setColor(new Color(200, 200, 190));
        g.setStroke(new BasicStroke(h * 0.02f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.draw(new Line2D.Double(w * 0.84, h * 0.05, w * 0.8, h * 0.95));
    }

    private static void serpent(Graphics2D g, int w, int h, Color c1, Color c2, Color eye) {
        g.setStroke(new BasicStroke(h * 0.16f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.setColor(INK);
        Path2D.Double body = new Path2D.Double();
        body.moveTo(w * 0.85, h * 0.9);
        body.curveTo(w * 0.1, h * 0.95, w * 0.05, h * 0.5, w * 0.5, h * 0.55);
        body.curveTo(w * 0.9, h * 0.6, w * 0.8, h * 0.25, w * 0.35, h * 0.28);
        g.draw(body);
        g.setStroke(new BasicStroke(h * 0.13f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.setColor(c1);
        g.draw(body);
        g.setStroke(new BasicStroke(h * 0.03f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.setColor(c2);
        g.draw(body);
        double hx = w * 0.3, hy = h * 0.26;
        outline(g, new Ellipse2D.Double(hx - w * 0.13, hy - h * 0.11, w * 0.26, h * 0.22), c1, 4f);
        eyes(g, hx + w * 0.02, hy - h * 0.02, w * 0.04, eye, true);
        teeth(g, hx - w * 0.02, hy + h * 0.06, w * 0.16, h * 0.05);
    }

    private static void dragon(Graphics2D g, int w, int h, Color c1, Color c2, Color eye) {
        for (int i = -1; i <= 1; i += 2) {
            Path2D.Double wing = new Path2D.Double();
            wing.moveTo(w * 0.5 + i * w * 0.12, h * 0.38);
            wing.lineTo(w * 0.5 + i * w * 0.5, h * 0.02);
            wing.lineTo(w * 0.5 + i * w * 0.42, h * 0.3);
            wing.lineTo(w * 0.5 + i * w * 0.48, h * 0.52);
            wing.lineTo(w * 0.5 + i * w * 0.3, h * 0.48);
            wing.lineTo(w * 0.5 + i * w * 0.22, h * 0.66);
            wing.lineTo(w * 0.5 + i * w * 0.14, h * 0.55);
            wing.closePath();
            outline(g, wing, c2, 4f);
        }
        for (int i = -1; i <= 1; i += 2) {
            outline(g, new RoundRectangle2D.Double(w * 0.5 + i * w * 0.14 - w * 0.06, h * 0.62, w * 0.12, h * 0.36, 16, 16), c1, 4f);
        }
        outline(g, new Ellipse2D.Double(w * 0.3, h * 0.3, w * 0.4, h * 0.45), c1, 5f);
        g.setColor(c2);
        for (int i = 0; i < 4; i++) g.fill(new Ellipse2D.Double(w * 0.42, h * (0.4 + i * 0.07), w * 0.16, h * 0.035));
        for (int i = -1; i <= 1; i += 2) {
            Path2D.Double horn = new Path2D.Double();
            horn.moveTo(w * 0.5 + i * w * 0.08, h * 0.2);
            horn.lineTo(w * 0.5 + i * w * 0.2, h * 0.02);
            horn.lineTo(w * 0.5 + i * w * 0.14, h * 0.24);
            horn.closePath();
            outline(g, horn, new Color(200, 190, 170), 3f);
        }
        outline(g, new Ellipse2D.Double(w * 0.36, h * 0.14, w * 0.28, h * 0.22), c1, 4f);
        eyes(g, w * 0.5, h * 0.23, w * 0.035, eye, true);
        teeth(g, w * 0.5, h * 0.3, w * 0.16, h * 0.04);
    }
}
