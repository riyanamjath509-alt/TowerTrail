import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

/** The whole game: state machine, waves, collisions, HUD and menus. */
public class GamePanel extends JPanel implements KeyListener {
    public static final int W = 960, H = 640, GROUND = 548;
    public static final double GRAV = 0.62;

    static final int TITLE = 0, STORY = 1, PLAY = 2, SKILL = 3, GAMEOVER = 4, ENDING = 5;

    static final String[][] STORY_PAGES = {
            {"Reto is a swordsman of absurd, overwhelming power.",
                    "One ordinary day, a strange light swallowed him whole..."},
            {"He woke at the foot of a colossal ancient tower.",
                    "A voice echoed from above:",
                    "\"Welcome to TOWER TRAIL. Climb all five floors,",
                    "defeat every guardian, and the key home is yours.\""},
            {"There is no other way back.",
                    "Every guardian he defeats will grant him a new power.",
                    "The climb begins now..."}};
    static final String[] ENDING_LINES = {
            "Reto slides the glowing key into the ancient door at the top of the tower.",
            "A blinding light fills the sky... and the tower fades away.",
            "He opens his eyes - back in his own world, stronger than ever.",
            "",
            "THE END",
            "Thanks for playing TOWER TRAIL!"};

    static final Font F_BIG = new Font("Serif", Font.BOLD, 54);
    static final Font F_MED = new Font("Serif", Font.BOLD, 30);
    static final Font F_SM = new Font("SansSerif", Font.BOLD, 14);
    static final Font F_TXT = new Font("SansSerif", Font.PLAIN, 18);

    // ---------------------------------------------------------------- state
    public Player player = new Player();
    public List<Enemy> enemies = new ArrayList<Enemy>();
    public List<Hazard> hazards = new ArrayList<Hazard>();
    public Rectangle[] platforms = Levels.platforms(0);

    public boolean left, right, down, jumpPressed, attackPressed, parryPressed, paused;
    public boolean[] skillPressed = new boolean[4];
    private boolean confirm;
    private Set<Integer> held = new HashSet<Integer>();

    int state = TITLE, level, storyPage, menuTick, wave, spawnTimer, spawnGap, afterBoss, deadTimer;
    long tick;
    boolean bossSpawned, bossDefeated, hasKey;
    Enemy boss;
    List<Integer> spawnQueue = new ArrayList<Integer>();
    BufferedImage bg;
    Random rnd = new Random();

    int shake, flash;
    String bannerTitle = "", bannerSub = "", toastText = "";
    int bannerT, bannerMax, toastT;

    static class Particle {
        double x, y, vx, vy;
        int life, max;
        Color c;
        float size;
    }

    static class FloatText {
        String s;
        double x, y;
        int life, max, size;
        Color c;
    }

    static class Amb {
        double x, y, vx, vy, sz, ph;
    }

    List<Particle> particles = new ArrayList<Particle>();
    List<FloatText> texts = new ArrayList<FloatText>();
    List<Amb> ambient = new ArrayList<Amb>();

    public GamePanel() {
        setPreferredSize(new Dimension(W, H));
        setFocusable(true);
        setDoubleBuffered(true);
        addKeyListener(this);
        bg = Levels.background(0);
        initAmbient(0);
    }

    public void start() {
        Timer t = new Timer(16, new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent e) {
                update();
                repaint();
            }
        });
        t.start();
    }

    // ---------------------------------------------------------------- input
    public void keyPressed(KeyEvent e) {
        int k = e.getKeyCode();
        boolean fresh = held.add(k);
        if (k == KeyEvent.VK_LEFT || k == KeyEvent.VK_A) left = true;
        if (k == KeyEvent.VK_RIGHT || k == KeyEvent.VK_D) right = true;
        if (k == KeyEvent.VK_DOWN || k == KeyEvent.VK_S) down = true;
        if (!fresh) return;
        if (k == KeyEvent.VK_UP || k == KeyEvent.VK_W || k == KeyEvent.VK_SPACE) jumpPressed = true;
        if (k == KeyEvent.VK_J || k == KeyEvent.VK_X || k == KeyEvent.VK_Z) attackPressed = true;
        if (k == KeyEvent.VK_K || k == KeyEvent.VK_SHIFT) parryPressed = true;
        if (k == KeyEvent.VK_1) skillPressed[0] = true;
        if (k == KeyEvent.VK_2) skillPressed[1] = true;
        if (k == KeyEvent.VK_3) skillPressed[2] = true;
        if (k == KeyEvent.VK_4) skillPressed[3] = true;
        if (k == KeyEvent.VK_ENTER || k == KeyEvent.VK_SPACE) confirm = true;
        if ((k == KeyEvent.VK_P || k == KeyEvent.VK_ESCAPE) && state == PLAY) paused = !paused;
    }

    public void keyReleased(KeyEvent e) {
        int k = e.getKeyCode();
        held.remove(k);
        if (k == KeyEvent.VK_LEFT || k == KeyEvent.VK_A) left = false;
        if (k == KeyEvent.VK_RIGHT || k == KeyEvent.VK_D) right = false;
        if (k == KeyEvent.VK_DOWN || k == KeyEvent.VK_S) down = false;
    }

    public void keyTyped(KeyEvent e) {
    }

    // ---------------------------------------------------------------- helpers used by other classes
    public void addHazard(Hazard h) {
        hazards.add(h);
    }

    public void shake(int n) {
        shake = Math.max(shake, n);
    }

    public void flash(int n) {
        flash = Math.max(flash, n);
    }

    public void toast(String s) {
        toastText = s;
        toastT = 120;
    }

    public void banner(String title, String sub, int frames) {
        bannerTitle = title;
        bannerSub = sub;
        bannerT = frames;
        bannerMax = frames;
    }

    public void burst(double x, double y, Color c, int n, double speed) {
        for (int i = 0; i < n; i++) {
            Particle p = new Particle();
            double a = rnd.nextDouble() * Math.PI * 2, s = (0.3 + rnd.nextDouble()) * speed;
            p.x = x;
            p.y = y;
            p.vx = Math.cos(a) * s;
            p.vy = Math.sin(a) * s - 1;
            p.life = p.max = 18 + rnd.nextInt(18);
            p.c = c;
            p.size = 3 + rnd.nextFloat() * 4;
            particles.add(p);
        }
    }

    public void floatText(String s, double x, double y, Color c, int size) {
        FloatText t = new FloatText();
        t.s = s;
        t.x = x;
        t.y = y;
        t.c = c;
        t.size = size;
        t.life = t.max = size > 20 ? 60 : 38;
        texts.add(t);
    }

    int countMinions() {
        int n = 0;
        for (Enemy e : enemies) if (!e.boss && !e.dying) n++;
        return n;
    }

    public void spawnMinion(int lv, int type, int side) {
        if (countMinions() >= 6) return;
        Enemy e = Enemy.minion(lv, type);
        e.x = side < 0 ? -45 : W + 45;
        e.y = e.flying ? GROUND - 170 : GROUND;
        e.spawnT = 40;
        e.facing = side < 0 ? 1 : -1;
        enemies.add(e);
    }

    public void onEnemyDeath(Enemy e) {
        burst(e.x, e.y - e.h * 0.5, e.boss ? new Color(255, 210, 90) : Color.WHITE, e.boss ? 60 : 14, e.boss ? 9 : 4);
        if (e.boss) {
            bossDefeated = true;
            afterBoss = 70;
            player.setMood("player_happy.png", 400);
            hazards.clear();
            for (Enemy o : enemies) {
                if (!o.boss && !o.dying) {
                    o.dying = true;
                    o.deathTimer = 14;
                }
            }
            Sfx.win();
        }
    }

    // ---------------------------------------------------------------- flow
    void resetGame() {
        player = new Player();
        hasKey = false;
    }

    void startLevel(int lv) {
        level = lv;
        enemies.clear();
        hazards.clear();
        particles.clear();
        texts.clear();
        spawnQueue.clear();
        platforms = Levels.platforms(lv);
        bg = Levels.background(lv);
        initAmbient(lv);
        player.resetForLevel();
        wave = -1;
        spawnTimer = 80;
        spawnGap = 0;
        boss = null;
        bossSpawned = false;
        bossDefeated = false;
        afterBoss = 0;
        deadTimer = 0;
        paused = false;
        banner("FLOOR " + (lv + 1), Levels.NAMES[lv].substring(Levels.NAMES[lv].indexOf('-') + 2), 150);
        state = PLAY;
    }

    void handleConfirm() {
        switch (state) {
            case TITLE:
                state = STORY;
                storyPage = 0;
                menuTick = 0;
                break;
            case STORY:
                storyPage++;
                menuTick = 0;
                if (storyPage >= STORY_PAGES.length) {
                    resetGame();
                    startLevel(0);
                }
                break;
            case SKILL:
                if (level < 4) {
                    startLevel(level + 1);
                } else {
                    state = ENDING;
                    menuTick = 0;
                    Sfx.win();
                }
                break;
            case GAMEOVER:
                startLevel(level);
                break;
            case ENDING:
                state = TITLE;
                menuTick = 0;
                break;
            default:
                break;
        }
    }

    void update() {
        tick++;
        if (flash > 0) flash--;
        if (shake > 0) shake--;
        if (bannerT > 0) bannerT--;
        if (toastT > 0) toastT--;
        if (confirm) {
            confirm = false;
            handleConfirm();
        }
        updateAmbient();
        if (state == PLAY) {
            if (!paused) updatePlay();
        } else {
            menuTick++;
            updateParticles();
        }
    }

    private void updatePlay() {
        if (player.hp > 0) {
            player.update(this);
        } else if (++deadTimer > 70) {
            state = GAMEOVER;
            menuTick = 0;
            return;
        }
        updateWaves();

        for (int i = enemies.size() - 1; i >= 0; i--) {
            Enemy e = enemies.get(i);
            e.update(this);
            if (e.removed) enemies.remove(i);
        }

        for (int i = hazards.size() - 1; i >= 0; i--) {
            Hazard h = hazards.get(i);
            h.update();
            if (h.active()) {
                if (h.friendly) {
                    for (Enemy e : enemies) {
                        if (!e.canBeHit() || h.hitSet.contains(e)) continue;
                        if (h.hits(e.hitbox())) {
                            h.hitSet.add(e);
                            e.damage(h.damage, this, h.cx);
                        }
                    }
                } else {
                    if (player.hp > 0 && !h.hitPlayer && player.parrying() && h.hits(player.parryBox())) {
                        player.onParry(this);
                        if (h.groundKill) { // projectiles get reflected back, stronger
                            h.friendly = true;
                            h.vx = -h.vx * 1.4;
                            h.vy = -h.vy * 1.4;
                            if (Math.abs(h.vx) + Math.abs(h.vy) < 0.1) h.vx = player.facing * 8;
                            h.damage = h.damage * 3 + 10;
                            h.hitSet.clear();
                            h.destroyOnHit = false;
                            h.groundKill = false;
                            h.orbitOwner = null;
                            h.hitScale = 1.0;
                            h.life = Math.max(h.life, 140);
                            h.delay = 0;
                        } else {            // melee / waves / beams are simply blocked
                            h.hitPlayer = true;
                        }
                    } else if (player.hp > 0 && !h.hitPlayer && h.hits(player.box())) {
                        if (player.hurt(h.damage, h.cx, this)) {
                            h.hitPlayer = true;
                            if (h.destroyOnHit) h.life = 0;
                        }
                    }
                    if (h.groundKill && h.orbitOwner == null && h.vy > 0 && h.cy > GROUND - 8) {
                        burst(h.cx, GROUND - 4, h.color, 8, 3);
                        h.life = 0;
                    }
                }
            }
            if (h.dead()) hazards.remove(i);
        }

        if (player.hp > 0) {
            for (Enemy e : enemies) {
                if (e.canHurtPlayer() && player.parrying() && e.hitbox().intersects(player.parryBox())) {
                    if (player.parryFlash <= 0) { // counter-attack
                        player.onParry(this);
                        e.damage(e.boss ? 20 : 30, this, player.x);
                        if (!e.boss) e.kvx = (e.x < player.x ? -1 : 1) * 12;
                    }
                } else if (e.canHurtPlayer() && e.hitbox().intersects(player.box())) {
                    player.hurt(e.contactDmg, e.x, this);
                }
            }
        }

        updateParticles();
        if (afterBoss > 0 && --afterBoss == 0) {
            if (level < 4) player.unlocked[level] = true;
            else hasKey = true;
            player.hp = player.maxHp;
            state = SKILL;
            menuTick = 0;
        }
    }

    private void updateWaves() {
        if (bossSpawned) return;
        if (spawnTimer > 0) {
            spawnTimer--;
            return;
        }
        if (!spawnQueue.isEmpty()) {
            if (--spawnGap <= 0) {
                int t = spawnQueue.remove(0);
                spawnMinion(level, t, rnd.nextBoolean() ? -1 : 1);
                spawnGap = 38;
            }
            return;
        }
        if (enemies.isEmpty()) {
            wave++;
            int[][] ws = Levels.WAVES[level];
            if (wave > 0) {
                player.hp = Math.min(player.maxHp, player.hp + 25);
                toast("Wave cleared!  +25 HP");
                player.setMood("player_happy.png", 100);
            }
            if (wave < ws.length) {
                for (int t : ws[wave]) spawnQueue.add(t);
                spawnGap = 10;
            } else {
                boss = Enemy.boss(level);
                boss.x = W - 220;
                boss.y = GROUND;
                boss.facing = -1;
                enemies.add(boss);
                bossSpawned = true;
                banner(boss.name, boss.title, 140);
                player.setMood("player_angry.png", 160);
                shake(14);
                Sfx.boom();
            }
        }
    }

    private void updateParticles() {
        for (int i = particles.size() - 1; i >= 0; i--) {
            Particle p = particles.get(i);
            p.x += p.vx;
            p.y += p.vy;
            p.vy += 0.15;
            if (--p.life <= 0) particles.remove(i);
        }
        for (int i = texts.size() - 1; i >= 0; i--) {
            FloatText t = texts.get(i);
            t.y -= 0.8;
            if (--t.life <= 0) texts.remove(i);
        }
    }

    private void initAmbient(int lv) {
        ambient.clear();
        for (int i = 0; i < 36; i++) {
            Amb a = new Amb();
            a.x = rnd.nextDouble() * W;
            a.y = rnd.nextDouble() * GROUND;
            a.sz = 2 + rnd.nextDouble() * 4;
            a.ph = rnd.nextDouble() * 6.28;
            switch (lv) {
                case 1: a.vx = 0.4 + rnd.nextDouble() * 0.5; a.vy = 0.3 + rnd.nextDouble() * 0.4; a.sz += 3; break;
                case 3: a.vx = 0; a.vy = -(0.3 + rnd.nextDouble() * 0.5); break;
                case 4: a.vx = 0.3; a.vy = -(0.5 + rnd.nextDouble() * 0.9); break;
                case 2: a.vx = 0.1; a.vy = -0.1; break;
                default: a.vx = -(0.5 + rnd.nextDouble()); a.vy = 0.4 + rnd.nextDouble() * 0.5; break;
            }
            ambient.add(a);
        }
    }

    private void updateAmbient() {
        for (Amb a : ambient) {
            a.x += a.vx + Math.sin(tick * 0.03 + a.ph) * 0.4;
            a.y += a.vy;
            if (a.x > W + 10) a.x = -10;
            if (a.x < -10) a.x = W + 10;
            if (a.y > GROUND) a.y = 0;
            if (a.y < 0) a.y = GROUND;
        }
    }

    // ---------------------------------------------------------------- painting
    @Override
    protected void paintComponent(Graphics g0) {
        super.paintComponent(g0);
        Graphics2D g = (Graphics2D) g0;
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        switch (state) {
            case TITLE: drawTitle(g); break;
            case STORY: drawStory(g); break;
            case PLAY:
                drawWorld(g);
                drawHud(g);
                drawOverlays(g);
                if (paused) {
                    g.setColor(new Color(0, 0, 0, 150));
                    g.fillRect(0, 0, W, H);
                    centered(g, "PAUSED", W / 2, H / 2, F_BIG, Color.WHITE);
                    centered(g, "Press P to resume", W / 2, H / 2 + 40, F_TXT, new Color(220, 220, 220));
                }
                break;
            case SKILL:
                drawWorld(g);
                drawHud(g);
                drawSkillScreen(g);
                break;
            case GAMEOVER:
                drawWorld(g);
                g.setColor(new Color(40, 0, 0, 170));
                g.fillRect(0, 0, W, H);
                centered(g, "YOU WERE DEFEATED", W / 2, H / 2 - 10, F_BIG, new Color(235, 70, 70));
                if ((menuTick / 30) % 2 == 0)
                    centered(g, "Press ENTER to retry " + Levels.NAMES[level].substring(0, 7), W / 2, H / 2 + 40, F_TXT, Color.WHITE);
                break;
            default: drawEnding(g); break;
        }
    }

    private void text(Graphics2D g, String s, int x, int y, Font f, Color c) {
        g.setFont(f);
        g.setColor(new Color(0, 0, 0, 190));
        g.drawString(s, x + 2, y + 2);
        g.setColor(c);
        g.drawString(s, x, y);
    }

    private void centered(Graphics2D g, String s, int cx, int y, Font f, Color c) {
        g.setFont(f);
        int w = g.getFontMetrics().stringWidth(s);
        text(g, s, cx - w / 2, y, f, c);
    }

    private List<String> wrap(Graphics2D g, String s, Font f, int maxW) {
        List<String> out = new ArrayList<String>();
        g.setFont(f);
        FontMetrics fm = g.getFontMetrics();
        String line = "";
        for (String word : s.split(" ")) {
            String t = line.isEmpty() ? word : line + " " + word;
            if (fm.stringWidth(t) > maxW) {
                out.add(line);
                line = word;
            } else {
                line = t;
            }
        }
        if (!line.isEmpty()) out.add(line);
        return out;
    }

    private void drawTitle(Graphics2D g) {
        g.drawImage(Assets.get("title.jpg"), 0, 0, W, H, null);
        g.setPaint(new GradientPaint(0, H - 190, new Color(0, 0, 0, 0), 0, H, new Color(0, 0, 0, 200)));
        g.fillRect(0, H - 190, W, 190);
        if ((menuTick / 30) % 2 == 0) centered(g, "Press ENTER to begin your climb", W / 2, H - 60, F_MED, new Color(255, 235, 170));
        centered(g, "A / D or arrows: move    W / Space: jump (double jump!)    J: sword    K: parry    1-4: skills    P: pause",
                W / 2, H - 22, F_SM, new Color(230, 230, 230));
    }

    private void drawStory(Graphics2D g) {
        g.drawImage(Assets.get("title.jpg"), 0, 0, W, H, null);
        g.setColor(new Color(8, 10, 18, 215));
        g.fillRect(0, 0, W, H);
        BufferedImage por = Assets.byHeight("player_front.png", 420, false, false);
        g.setColor(new Color(255, 255, 255, 30));
        g.fillRoundRect(50, 130, por.getWidth() + 40, 450, 20, 20);
        g.drawImage(por, 70, 145, null);
        text(g, "RETO", 60, 112, F_MED, new Color(150, 220, 130));
        String[] lines = STORY_PAGES[Math.min(storyPage, STORY_PAGES.length - 1)];
        int shown = menuTick * 2;
        int y = 200;
        for (String line : lines) {
            int n = Math.max(0, Math.min(line.length(), shown));
            shown -= line.length();
            text(g, line.substring(0, n), 380, y, F_TXT, Color.WHITE);
            y += 38;
        }
        text(g, "Page " + (storyPage + 1) + " / " + STORY_PAGES.length, 380, 470, F_SM, new Color(170, 170, 170));
        if ((menuTick / 30) % 2 == 0) text(g, "Press ENTER", 380, 500, F_SM, new Color(255, 235, 170));
    }

    private void drawEnding(Graphics2D g) {
        g.drawImage(Assets.get("title.jpg"), 0, 0, W, H, null);
        g.setColor(new Color(255, 250, 230, Math.max(0, 255 - menuTick * 2)));
        g.fillRect(0, 0, W, H);
        g.setColor(new Color(6, 8, 16, Math.min(215, menuTick * 2)));
        g.fillRect(0, 0, W, H);
        int shown = Math.max(0, menuTick - 40) * 2;
        int y = 180;
        for (int i = 0; i < ENDING_LINES.length; i++) {
            String line = ENDING_LINES[i];
            int n = Math.max(0, Math.min(line.length(), shown));
            shown -= line.length();
            if (i == 4) centered(g, line.substring(0, n), W / 2, y + 20, F_BIG, new Color(255, 225, 120));
            else centered(g, line.substring(0, n), W / 2, y, F_TXT, Color.WHITE);
            y += (i == 4) ? 70 : 38;
        }
        if (menuTick > 380 && (menuTick / 30) % 2 == 0)
            centered(g, "Press ENTER to return to the title", W / 2, H - 50, F_SM, new Color(210, 210, 210));
    }

    private void drawWorld(Graphics2D g0) {
        Graphics2D g = (Graphics2D) g0.create();
        if (shake > 0) {
            int s = Math.min(6, shake / 2 + 1);
            g.translate(rnd.nextInt(2 * s + 1) - s, rnd.nextInt(2 * s + 1) - s);
        }
        g.drawImage(bg, 0, 0, null);
        Color ac = Levels.AMBIENT[level];
        for (Amb a : ambient) {
            g.setColor(new Color(ac.getRed(), ac.getGreen(), ac.getBlue(), 120));
            if (level == 1) g.fillRect((int) a.x, (int) a.y, (int) a.sz + 2, (int) a.sz);
            else g.fillOval((int) a.x, (int) a.y, (int) a.sz, (int) a.sz);
        }
        for (Rectangle r : platforms) Levels.drawPlatform(g, r, level);
        for (Enemy e : enemies) if (!e.boss) e.draw(g, tick);
        for (Enemy e : enemies) if (e.boss) e.draw(g, tick);
        if (player.hp > 0 || deadTimer < 40) player.draw(g);
        for (Hazard h : hazards) h.draw(g, tick);
        for (Particle p : particles) {
            float a = Math.max(0f, Math.min(1f, p.life / (float) p.max));
            g.setColor(new Color(p.c.getRed(), p.c.getGreen(), p.c.getBlue(), (int) (230 * a)));
            double s = p.size * (0.5 + a);
            g.fill(new Ellipse2D.Double(p.x - s / 2, p.y - s / 2, s, s));
        }
        for (FloatText t : texts) {
            float a = Math.max(0f, Math.min(1f, t.life / (float) t.max));
            Font f = new Font("SansSerif", Font.BOLD, t.size);
            g.setFont(f);
            int w = g.getFontMetrics().stringWidth(t.s);
            g.setColor(new Color(0, 0, 0, (int) (200 * a)));
            g.drawString(t.s, (int) t.x - w / 2 + 2, (int) t.y + 2);
            g.setColor(new Color(t.c.getRed(), t.c.getGreen(), t.c.getBlue(), (int) (255 * a)));
            g.drawString(t.s, (int) t.x - w / 2, (int) t.y);
        }
        g.dispose();
        if (flash > 0) {
            g0.setColor(new Color(255, 255, 255, Math.min(200, flash * 16)));
            g0.fillRect(0, 0, W, H);
        }
    }

    private void drawSkillIcon(Graphics2D g, int i, double cx, double cy, double s) {
        Stroke old = g.getStroke();
        switch (i) {
            case 0: {
                g.setStroke(new BasicStroke((float) (s * 0.1), BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                g.setColor(new Color(120, 220, 255));
                for (int k = 0; k < 2; k++) {
                    double ox = cx - s * 0.2 + k * s * 0.3;
                    Path2D.Double p = new Path2D.Double();
                    p.moveTo(ox, cy - s * 0.3);
                    p.lineTo(ox + s * 0.2, cy);
                    p.lineTo(ox, cy + s * 0.3);
                    g.draw(p);
                }
                break;
            }
            case 1: {
                Path2D.Double f = new Path2D.Double();
                f.moveTo(cx, cy - s * 0.45);
                f.quadTo(cx + s * 0.45, cy + s * 0.05, cx, cy + s * 0.4);
                f.quadTo(cx - s * 0.45, cy + s * 0.05, cx, cy - s * 0.45);
                g.setColor(new Color(255, 110, 20));
                g.fill(f);
                g.setColor(new Color(255, 225, 110));
                g.fill(new Ellipse2D.Double(cx - s * 0.14, cy - s * 0.02, s * 0.28, s * 0.34));
                break;
            }
            case 2: {
                g.setColor(new Color(255, 200, 40));
                g.fill(new Ellipse2D.Double(cx - s * 0.2, cy - s * 0.2, s * 0.4, s * 0.4));
                g.setStroke(new BasicStroke((float) (s * 0.07), BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                for (int k = 0; k < 8; k++) {
                    double a = k * Math.PI / 4;
                    g.draw(new Line2D.Double(cx + Math.cos(a) * s * 0.28, cy + Math.sin(a) * s * 0.28,
                            cx + Math.cos(a) * s * 0.44, cy + Math.sin(a) * s * 0.44));
                }
                break;
            }
            case 3: {
                g.setStroke(new BasicStroke((float) (s * 0.09), BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                g.setColor(new Color(220, 235, 255));
                g.draw(new Line2D.Double(cx - s * 0.3, cy + s * 0.3, cx + s * 0.34, cy - s * 0.34));
                g.setColor(new Color(235, 185, 60));
                g.draw(new Line2D.Double(cx - s * 0.2, cy + s * 0.04, cx - s * 0.04, cy + s * 0.2));
                break;
            }
            case 5: {
                Path2D.Double sh = new Path2D.Double();
                sh.moveTo(cx, cy - s * 0.4);
                sh.lineTo(cx + s * 0.32, cy - s * 0.28);
                sh.quadTo(cx + s * 0.32, cy + s * 0.22, cx, cy + s * 0.42);
                sh.quadTo(cx - s * 0.32, cy + s * 0.22, cx - s * 0.32, cy - s * 0.28);
                sh.closePath();
                g.setColor(new Color(90, 160, 235));
                g.fill(sh);
                g.setColor(new Color(235, 245, 255));
                g.setStroke(new BasicStroke((float) (s * 0.06), BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                g.draw(sh);
                g.draw(new Line2D.Double(cx, cy - s * 0.28, cx, cy + s * 0.3));
                break;
            }
            default: {
                g.setColor(new Color(255, 215, 80));
                g.setStroke(new BasicStroke((float) (s * 0.09)));
                g.draw(new Ellipse2D.Double(cx - s * 0.36, cy - s * 0.16, s * 0.3, s * 0.3));
                g.draw(new Line2D.Double(cx - s * 0.06, cy - s * 0.01, cx + s * 0.4, cy - s * 0.01));
                g.draw(new Line2D.Double(cx + s * 0.28, cy - s * 0.01, cx + s * 0.28, cy + s * 0.14));
                g.draw(new Line2D.Double(cx + s * 0.4, cy - s * 0.01, cx + s * 0.4, cy + s * 0.14));
                break;
            }
        }
        g.setStroke(old);
    }

    private void drawHud(Graphics2D g) {
        g.setColor(new Color(0, 0, 0, 150));
        g.fillRoundRect(10, 10, 400, 106, 16, 16);
        BufferedImage por = Assets.byHeight(player.portrait(), 66, false, false);
        g.drawImage(por, 16, 18, null);
        text(g, "RETO", 94, 28, F_SM, new Color(150, 220, 130));
        int bx = 94, by = 34, bw = 298, bh = 16;
        g.setColor(new Color(60, 20, 20));
        g.fillRoundRect(bx, by, bw, bh, 8, 8);
        int fw = (int) (bw * Math.max(0, player.hp) / (double) player.maxHp);
        g.setPaint(new GradientPaint(bx, by, new Color(245, 90, 90), bx, by + bh, new Color(170, 30, 40)));
        g.fillRoundRect(bx, by, fw, bh, 8, 8);
        g.setColor(Color.WHITE);
        g.drawRoundRect(bx, by, bw, bh, 8, 8);
        g.setFont(F_SM);
        g.drawString(player.hp + " / " + player.maxHp, bx + 8, by + 13);

        for (int i = 0; i < 4; i++) {
            int sx = 94 + i * 60, sy = 60, sz = 48;
            g.setColor(new Color(25, 28, 40, 230));
            g.fillRoundRect(sx, sy, sz, sz, 10, 10);
            if (player.unlocked[i]) {
                drawSkillIcon(g, i, sx + sz / 2.0, sy + sz / 2.0, sz);
                if (player.cd[i] > 0) {
                    double frac = player.cd[i] / (double) Player.MAXCD[i];
                    g.setColor(new Color(0, 0, 0, 170));
                    g.fillRoundRect(sx, sy, sz, (int) (sz * frac), 10, 10);
                    String sec = String.valueOf((int) Math.ceil(player.cd[i] / 60.0));
                    g.setFont(F_SM);
                    g.setColor(Color.WHITE);
                    g.drawString(sec, sx + sz / 2 - 4, sy + sz / 2 + 5);
                }
            } else {
                g.setColor(new Color(110, 110, 120));
                g.setFont(F_MED);
                g.drawString("?", sx + 17, sy + 33);
            }
            g.setColor(new Color(255, 255, 255, 200));
            g.drawRoundRect(sx, sy, sz, sz, 10, 10);
            g.setFont(F_SM);
            g.setColor(new Color(255, 235, 170));
            g.drawString(String.valueOf(i + 1), sx + 4, sy + 13);
        }

        { // parry slot
            int sx = 94 + 4 * 60, sy = 60, sz = 48;
            g.setColor(new Color(25, 28, 40, 230));
            g.fillRoundRect(sx, sy, sz, sz, 10, 10);
            drawSkillIcon(g, 5, sx + sz / 2.0, sy + sz / 2.0, sz);
            if (player.parryCd > 0) {
                g.setColor(new Color(0, 0, 0, 170));
                g.fillRoundRect(sx, sy, sz, (int) (sz * player.parryCd / 42.0), 10, 10);
            }
            g.setColor(new Color(255, 255, 255, 200));
            g.drawRoundRect(sx, sy, sz, sz, 10, 10);
            g.setFont(F_SM);
            g.setColor(new Color(255, 235, 170));
            g.drawString("K", sx + 4, sy + 13);
        }

        boolean showBoss = boss != null && !boss.removed;
        int ph = showBoss ? 76 : 36;
        g.setColor(new Color(0, 0, 0, 130));
        g.fillRoundRect(420, 10, 530, ph, 14, 14);
        text(g, Levels.NAMES[level], 434, 33, F_SM, new Color(230, 230, 230));
        if (showBoss) {
            text(g, boss.name + " - " + boss.title, 434, 54, F_SM, new Color(255, 220, 150));
            int x = 434, y = 61, w = 502, h = 16;
            g.setColor(new Color(50, 20, 20));
            g.fillRoundRect(x, y, w, h, 8, 8);
            double frac = Math.max(0, boss.hp) / (double) boss.maxHp;
            Color c1 = boss.phase == 2 ? new Color(255, 70, 40) : new Color(220, 70, 70);
            g.setPaint(new GradientPaint(x, y, c1.brighter(), x, y + h, c1.darker()));
            g.fillRoundRect(x, y, (int) (w * frac), h, 8, 8);
            g.setColor(Color.WHITE);
            g.drawRoundRect(x, y, w, h, 8, 8);
        }
    }

    private void drawOverlays(Graphics2D g) {
        if (bannerT > 0) {
            float fade = Math.min(1f, Math.min(bannerT, bannerMax - bannerT) / 20f);
            fade = Math.max(0f, fade);
            Composite old = g.getComposite();
            g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, fade));
            centered(g, bannerTitle, W / 2, 200, F_BIG, new Color(255, 232, 170));
            centered(g, bannerSub, W / 2, 245, F_MED, Color.WHITE);
            g.setComposite(old);
        }
        if (toastT > 0) {
            g.setFont(F_SM);
            int w = g.getFontMetrics().stringWidth(toastText) + 30;
            g.setColor(new Color(0, 0, 0, 170));
            g.fillRoundRect(W / 2 - w / 2, H - 62, w, 30, 14, 14);
            g.setColor(Color.WHITE);
            g.drawString(toastText, W / 2 - w / 2 + 15, H - 42);
        }
        if (level == 0 && wave <= 0 && !bossSpawned && tick % 600 < 400) {
            // gentle reminder of the controls on the first floor
            centered(g, "Move: A/D   Jump: W/Space (x2)   Sword: J   Parry: K   Skills: 1-4", W / 2, H - 14, F_SM, new Color(255, 255, 255, 200));
        }
    }

    private void drawSkillScreen(Graphics2D g) {
        g.setColor(new Color(5, 6, 14, 200));
        g.fillRect(0, 0, W, H);
        int px = 170, py = 90, pw = 620, ph = 440;
        g.setColor(new Color(24, 22, 40, 240));
        g.fillRoundRect(px, py, pw, ph, 26, 26);
        g.setColor(new Color(255, 215, 120));
        g.setStroke(new BasicStroke(3f));
        g.drawRoundRect(px, py, pw, ph, 26, 26);
        g.setStroke(new BasicStroke(1f));
        boolean last = level == 4;
        g.drawImage(Assets.byHeight("player_happy.png", 90, false, false), px + 24, py + 22, null);
        centered(g, Levels.BOSS_NAMES[level] + " DEFEATED!", W / 2, py + 54, F_MED, new Color(255, 232, 170));
        centered(g, last ? "YOU FOUND THE KEY!" : "NEW SKILL UNLOCKED", W / 2, py + 92, F_SM, new Color(150, 220, 130));
        double pulse = 1 + 0.06 * Math.sin(menuTick * 0.15);
        drawSkillIcon(g, last ? 4 : level, W / 2.0, py + 170, 110 * pulse);
        centered(g, Levels.SKILL_NAMES[level], W / 2, py + 262, new Font("Serif", Font.BOLD, 40), Color.WHITE);
        int y = py + 305;
        for (String line : wrap(g, Levels.SKILL_DESC[level], F_TXT, pw - 90)) {
            centered(g, line, W / 2, y, F_TXT, new Color(225, 225, 235));
            y += 26;
        }
        if ((menuTick / 30) % 2 == 0)
            centered(g, last ? "Press ENTER to use the key..." : "Press ENTER to climb to the next floor", W / 2, py + ph - 24, F_SM, new Color(255, 235, 170));
    }
}
