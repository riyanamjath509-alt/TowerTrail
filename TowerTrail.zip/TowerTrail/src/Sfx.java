import javax.sound.sampled.*;

/** Tiny synthesized sound effects (no audio files needed). Fails silently if no audio device. */
public class Sfx {
    private static boolean enabled = true;
    private static int active = 0;

    private static void play(final double freq, final int ms, final double vol, final int type, final double slide) {
        if (!enabled || active > 6) return;
        active++;
        Thread t = new Thread(new Runnable() {
            public void run() {
                try {
                    float sr = 22050f;
                    int n = (int) (sr * ms / 1000.0);
                    byte[] buf = new byte[n];
                    double phase = 0;
                    for (int i = 0; i < n; i++) {
                        double p = i / (double) n;
                        phase += 2 * Math.PI * (freq + slide * p) / sr;
                        double s;
                        if (type == 0) s = Math.sin(phase);
                        else if (type == 1) s = Math.sin(phase) > 0 ? 1 : -1;
                        else s = Math.random() * 2 - 1;
                        buf[i] = (byte) (s * (1 - p) * vol * 110);
                    }
                    AudioFormat fmt = new AudioFormat(sr, 8, 1, true, false);
                    final Clip clip = AudioSystem.getClip();
                    clip.open(fmt, buf, 0, n);
                    clip.addLineListener(new LineListener() {
                        public void update(LineEvent ev) {
                            if (ev.getType() == LineEvent.Type.STOP) clip.close();
                        }
                    });
                    clip.start();
                } catch (Throwable ex) {
                    enabled = false;
                } finally {
                    active--;
                }
            }
        });
        t.setDaemon(true);
        t.start();
    }

    public static void slash()  { play(300, 80, 0.30, 2, 0); }
    public static void hit()    { play(170, 60, 0.35, 1, -60); }
    public static void jump()   { play(380, 90, 0.25, 0, 350); }
    public static void hurt()   { play(140, 170, 0.45, 1, -80); }
    public static void shoot()  { play(500, 100, 0.20, 1, -250); }
    public static void dash()   { play(200, 140, 0.35, 2, 0); }
    public static void skill()  { play(300, 260, 0.40, 0, 700); }
    public static void boom()   { play(90, 380, 0.55, 2, 0); }
    public static void parry()  { play(900, 130, 0.35, 0, -350); }
    public static void win()    { play(400, 500, 0.40, 0, 600); }
}
