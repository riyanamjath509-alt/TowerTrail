import java.awt.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.util.Random;

/** Level data: names, enemy waves, platforms and procedurally painted backgrounds. */
public class Levels {
    public static final String[] NAMES = {
            "Floor 1 - The Mossy Gate", "Floor 2 - The Forbidden Library", "Floor 3 - The Living Grove",
            "Floor 4 - The Drowned City", "Floor 5 - The Ashen Summit"};
    public static final String[] BOSS_NAMES = {"IGLUGON", "BOBKUBO", "TEON", "GOLAR", "GRODRE"};
    public static final String[] BOSS_TITLES = {"The Moss Beast", "The Book Magic Beast", "The One-Eyed Tree",
            "The Fallen Guardian", "The Ancient Black Dragon Lord"};
    public static final String[] SKILL_NAMES = {"Quick Charge", "Heavenly Fire Slash", "Solar Slash",
            "Mighty Sword Throw", "Key to Return Home"};
    public static final String[] SKILL_DESC = {
            "Dash forward in a blink and slash everything in your path. You can't be hurt while charging.  [Key 1]",
            "Launch a blazing wave of heavenly fire that pierces every enemy.  [Key 2]",
            "Unleash a huge golden crescent that burns everything in front of you.  [Key 3]",
            "Hurl your sword. It spins through enemies, then flies back to your hand.  [Key 4]",
            "A glowing key that opens the way back to your own world!"};

    /** WAVES[level][wave] = list of minion types. After the last wave the boss appears. */
    public static final int[][][] WAVES = {
            {{0, 0, 0}, {0, 0, 0, 0}},
            {{0, 1}, {0, 0, 1, 1}},
            {{0, 1, 2}, {0, 1, 2, 2}},
            {{0, 2}, {0, 1, 2, 1}},
            {{0, 2}, {1, 2, 3, 0}}};

    static final Color[][] SKY = {
            {new Color(110, 170, 230), new Color(205, 232, 190)},
            {new Color(26, 14, 46), new Color(78, 44, 98)},
            {new Color(18, 44, 28), new Color(92, 104, 44)},
            {new Color(8, 40, 46), new Color(40, 104, 96)},
            {new Color(16, 4, 6), new Color(120, 34, 16)}};
    static final Color[] FAR = {new Color(92, 135, 120), new Color(52, 34, 78), new Color(40, 66, 38),
            new Color(24, 70, 70), new Color(50, 14, 14)};
    static final Color[] GROUND_TOP = {new Color(88, 150, 70), new Color(104, 86, 130), new Color(78, 110, 46),
            new Color(70, 130, 120), new Color(110, 52, 34)};
    static final Color[] GROUND_BODY = {new Color(94, 72, 48), new Color(58, 46, 74), new Color(60, 46, 30),
            new Color(36, 58, 58), new Color(40, 22, 22)};
    static final Color[] AMBIENT = {new Color(150, 220, 100), new Color(245, 235, 205), new Color(255, 190, 70),
            new Color(160, 235, 240), new Color(255, 140, 50)};

    public static Rectangle[] platforms(int level) {
        switch (level % 3) {
            case 1:
                return new Rectangle[]{new Rectangle(70, 430, 190, 16), new Rectangle(700, 430, 190, 16),
                        new Rectangle(385, 330, 190, 16)};
            case 2:
                return new Rectangle[]{new Rectangle(150, 400, 170, 16), new Rectangle(640, 400, 170, 16),
                        new Rectangle(395, 290, 170, 16)};
            default:
                return new Rectangle[]{new Rectangle(110, 425, 200, 16), new Rectangle(650, 425, 200, 16),
                        new Rectangle(380, 318, 200, 16)};
        }
    }

    public static void drawPlatform(Graphics2D g, Rectangle r, int level) {
        g.setColor(new Color(0, 0, 0, 60));
        g.fillRect(r.x + 4, r.y + 8, r.width, r.height);
        g.setColor(GROUND_BODY[level].brighter());
        g.fillRoundRect(r.x, r.y, r.width, r.height, 8, 8);
        g.setColor(GROUND_TOP[level]);
        g.fillRoundRect(r.x, r.y, r.width, 6, 6, 6);
        g.setColor(new Color(0, 0, 0, 70));
        for (int x = r.x + 30; x < r.x + r.width; x += 40) g.drawLine(x, r.y + 6, x, r.y + r.height);
    }

    public static BufferedImage background(int level) {
        int W = GamePanel.W, H = GamePanel.H, GY = GamePanel.GROUND;
        BufferedImage img = new BufferedImage(W, H, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        Random r = new Random(level * 977L + 13);

        g.setPaint(new GradientPaint(0, 0, SKY[level][0], 0, GY, SKY[level][1]));
        g.fillRect(0, 0, W, H);

        // far silhouettes
        Path2D.Double far = new Path2D.Double();
        far.moveTo(0, GY);
        for (int x = 0; x <= W; x += 60) far.lineTo(x, GY - 150 - r.nextInt(150));
        far.lineTo(W, GY);
        far.closePath();
        g.setColor(FAR[level]);
        g.fill(far);

        switch (level) {
            case 0: // forest
                for (int x = -20; x < W; x += 85) {
                    int th = 110 + r.nextInt(90);
                    g.setColor(new Color(70, 50, 34));
                    g.fillRect(x + 28, GY - th, 16, th);
                    g.setColor(new Color(40 + r.nextInt(30), 100 + r.nextInt(40), 50));
                    g.fillOval(x, GY - th - 50, 76, 76);
                    g.fillOval(x + 18, GY - th - 72, 60, 60);
                }
                break;
            case 1: // bookshelves
                for (int x = 0; x < W; x += 120) {
                    g.setColor(new Color(36, 22, 50));
                    g.fillRect(x + 8, 120, 104, GY - 120);
                    for (int s = 0; s < 6; s++) {
                        int sy = 130 + s * 66;
                        g.setColor(new Color(62, 40, 80));
                        g.fillRect(x + 8, sy + 54, 104, 6);
                        int bx = x + 12;
                        while (bx < x + 104) {
                            int bw = 6 + r.nextInt(8), bh = 30 + r.nextInt(22);
                            g.setColor(new Color(70 + r.nextInt(120), 40 + r.nextInt(60), 90 + r.nextInt(120)));
                            g.fillRect(bx, sy + 54 - bh, bw, bh);
                            bx += bw + 1;
                        }
                    }
                }
                break;
            case 2: // giant trunks + glow
                for (int x = 20; x < W; x += 200) {
                    int tx = x + r.nextInt(60);
                    g.setColor(new Color(34, 26, 16));
                    g.fillRect(tx, 0, 62 + r.nextInt(30), GY);
                    g.setColor(new Color(255, 150, 40, 90));
                    for (int k = 0; k < 4; k++) g.fillOval(tx + 10 + r.nextInt(40), 60 + r.nextInt(380), 8, 8);
                }
                g.setPaint(new GradientPaint(0, GY - 160, new Color(255, 170, 60, 0), 0, GY, new Color(255, 170, 60, 70)));
                g.fillRect(0, GY - 160, W, 160);
                break;
            case 3: // drowned ruins
                for (int x = 0; x < W; x += 110) {
                    int ph = 140 + r.nextInt(220);
                    g.setColor(new Color(18, 62, 62));
                    g.fillRect(x + 20, GY - ph, 44, ph);
                    g.fillRect(x + 12, GY - ph - 12, 60, 14);
                    g.setColor(new Color(60, 200, 150, 60));
                    g.fillRect(x + 28, GY - ph, 6, ph);
                }
                g.setPaint(new GradientPaint(0, GY - 120, new Color(80, 230, 220, 0), 0, GY, new Color(80, 230, 220, 80)));
                g.fillRect(0, GY - 120, W, 120);
                break;
            default: // burning city
                g.setPaint(new GradientPaint(0, GY - 260, new Color(255, 100, 20, 0), 0, GY, new Color(255, 100, 20, 110)));
                g.fillRect(0, GY - 260, W, 260);
                for (int x = -10; x < W; x += 90) {
                    int th = 120 + r.nextInt(240);
                    Path2D.Double tw = new Path2D.Double();
                    tw.moveTo(x, GY);
                    tw.lineTo(x, GY - th);
                    tw.lineTo(x + 22, GY - th - 36);
                    tw.lineTo(x + 44, GY - th);
                    tw.lineTo(x + 70, GY - th + 10);
                    tw.lineTo(x + 70, GY);
                    tw.closePath();
                    g.setColor(new Color(20, 8, 10));
                    g.fill(tw);
                    g.setColor(new Color(255, 150, 40, 200));
                    for (int k = 0; k < 4; k++) g.fillRect(x + 10 + r.nextInt(44), GY - th + 20 + r.nextInt(Math.max(10, th - 40)), 5, 8);
                }
                break;
        }

        // ground
        g.setPaint(new GradientPaint(0, GY, GROUND_TOP[level], 0, H, GROUND_BODY[level]));
        g.fillRect(0, GY, W, H - GY);
        g.setColor(GROUND_TOP[level].brighter());
        g.fillRect(0, GY, W, 5);
        g.setColor(new Color(0, 0, 0, 55));
        int row = 0;
        for (int y = GY + 5; y < H; y += 30) {
            g.drawLine(0, y, W, y);
            for (int x = (row % 2 == 0 ? 0 : 40); x < W; x += 80) g.drawLine(x, y, x, Math.min(H, y + 30));
            row++;
        }
        g.dispose();
        return img;
    }
}
