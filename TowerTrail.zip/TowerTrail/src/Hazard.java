import java.awt.*;
import java.awt.geom.*;
import java.util.HashSet;
import java.util.Set;

/**
 * Anything that can hurt: boss attacks, projectiles, warning zones AND the player's own
 * sword slash / skills (friendly = true damages enemies instead of the player).
 */
public class Hazard {
    public static final int RECT = 0, OVAL = 1, FIRE = 2, SWORD = 3, BEAM = 4, PAGE = 5,
            SLASH = 6, SOLAR = 7, COLUMN = 8, AXE = 9;

    public double cx, cy, w, h, vx, vy, grav, rot, rotSpeed, hitScale = 1.0;
    public int shape, damage, delay, life, maxLife, age, dir = 1, rehit, boomerangAt;
    public boolean friendly, hitPlayer, destroyOnHit, groundKill, homeBack;
    public Color color, color2;
    public Set<Enemy> hitSet = new HashSet<Enemy>();

    // optional custom warning marker (used by falling objects)
    public boolean hasWarn, warnOval;
    public double wx, wy, ww, wh;

    // orbiting (Page Circle)
    public Enemy orbitOwner;
    public double orbitAngle, orbitSpin, orbitRadius, launchSpeed;
    public int orbitFrames;

    public Player owner; // for the returning sword

    public Hazard(int shape, double cx, double cy, double w, double h, int damage, int delay, int life, Color color) {
        this.shape = shape;
        this.cx = cx;
        this.cy = cy;
        this.w = w;
        this.h = h;
        this.damage = damage;
        this.delay = delay;
        this.life = life;
        this.maxLife = life;
        this.color = color;
        this.color2 = color;
    }

    /** A moving projectile. */
    public static Hazard shot(int shape, double x, double y, double vx, double vy, int size, int dmg,
                              Color c, Color c2, int life) {
        Hazard hz = new Hazard(shape, x, y, size, size, dmg, 0, life, c);
        hz.vx = vx;
        hz.vy = vy;
        hz.color2 = c2;
        hz.destroyOnHit = true;
        hz.groundKill = true;
        hz.hitScale = 0.7;
        return hz;
    }

    public boolean active() {
        return delay <= 0;
    }

    public void update() {
        if (delay > 0) {
            delay--;
            return;
        }
        age++;
        rot += rotSpeed;
        if (orbitOwner != null) {
            double oy = orbitOwner.y - orbitOwner.h * 0.5;
            if (age < orbitFrames) {
                double ang = orbitAngle + orbitSpin * age;
                cx = orbitOwner.x + Math.cos(ang) * orbitRadius;
                cy = oy + Math.sin(ang) * orbitRadius * 0.7;
            } else {
                double dx = cx - orbitOwner.x, dy = cy - oy;
                double len = Math.max(1.0, Math.hypot(dx, dy));
                vx = dx / len * launchSpeed;
                vy = dy / len * launchSpeed;
                orbitOwner = null;
            }
        } else {
            if (homeBack && owner != null && age > boomerangAt) {
                double dx = owner.x - cx, dy = (owner.y - 45) - cy;
                double len = Math.max(1.0, Math.hypot(dx, dy));
                vx = dx / len * 17;
                vy = dy / len * 17;
                if (len < 30) life = 0;
            }
            cx += vx;
            cy += vy;
            vy += grav;
        }
        if (boomerangAt > 0 && !homeBack && age == boomerangAt) {
            vx = -vx;
            vy = -vy;
            hitSet.clear();
            hitPlayer = false;
        }
        if (rehit > 0 && age % rehit == 0) hitSet.clear();
        life--;
    }

    public boolean dead() {
        return life <= 0 || cx < -260 || cx > GamePanel.W + 260 || cy > GamePanel.H + 150 || cy < -420;
    }

    public boolean hits(Rectangle2D r) {
        double hw = w * hitScale, hh = h * hitScale;
        if (shape == OVAL) return new Ellipse2D.Double(cx - hw / 2, cy - hh / 2, hw, hh).intersects(r);
        return new Rectangle2D.Double(cx - hw / 2, cy - hh / 2, hw, hh).intersects(r);
    }

    static Color alpha(Color c, int a) {
        return new Color(c.getRed(), c.getGreen(), c.getBlue(), Math.max(0, Math.min(255, a)));
    }

    // ------------------------------------------------------------------ drawing
    public void draw(Graphics2D g, long tick) {
        if (delay > 0) {
            if (!friendly) drawWarning(g, tick);
            return;
        }
        float fade = (float) Math.max(0.0, Math.min(1.0, life / 10.0));
        AffineTransform oldT = g.getTransform();
        Stroke oldS = g.getStroke();
        switch (shape) {
            case RECT:   drawRect(g, fade); break;
            case OVAL:   drawOval(g, fade); break;
            case FIRE:   drawFire(g); break;
            case SWORD:  drawSword(g); break;
            case BEAM:   drawBeam(g, fade, tick); break;
            case PAGE:   drawPage(g); break;
            case SLASH:  drawSlash(g); break;
            case SOLAR:  drawSolar(g, fade); break;
            case COLUMN: drawColumn(g); break;
            case AXE:    drawAxe(g); break;
            default: break;
        }
        g.setTransform(oldT);
        g.setStroke(oldS);
    }

    private void drawWarning(Graphics2D g, long tick) {
        float pulse = 0.5f + 0.5f * (float) Math.sin(tick * 0.5);
        double x0, y0, w0, h0;
        boolean oval;
        if (hasWarn) {
            x0 = wx; y0 = wy; w0 = ww; h0 = wh; oval = warnOval;
        } else {
            x0 = cx - w / 2; y0 = cy - h / 2; w0 = w; h0 = h; oval = (shape == OVAL);
        }
        Shape s = oval ? new Ellipse2D.Double(x0, y0, w0, h0) : new Rectangle2D.Double(x0, y0, w0, h0);
        g.setColor(alpha(color, (int) (40 + 60 * pulse)));
        g.fill(s);
        Stroke old = g.getStroke();
        g.setStroke(new BasicStroke(2f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10f, new float[]{8f, 6f}, 0f));
        g.setColor(alpha(Color.WHITE, (int) (110 + 100 * pulse)));
        g.draw(s);
        g.setStroke(old);
    }

    private void drawRect(Graphics2D g, float fade) {
        double x = cx - w / 2, y = cy - h / 2;
        g.setPaint(new GradientPaint((float) x, (float) y, alpha(color2, (int) (235 * fade)),
                (float) x, (float) (y + h), alpha(color, (int) (170 * fade))));
        g.fill(new RoundRectangle2D.Double(x, y, w, h, 14, 14));
        g.setColor(alpha(Color.WHITE, (int) (200 * fade)));
        g.setStroke(new BasicStroke(2f));
        g.draw(new RoundRectangle2D.Double(x + 2, y + 2, w - 4, h - 4, 12, 12));
    }

    private void drawOval(Graphics2D g, float fade) {
        double x = cx - w / 2, y = cy - h / 2;
        g.setColor(alpha(color, (int) (150 * fade)));
        g.fill(new Ellipse2D.Double(x, y, w, h));
        g.setColor(alpha(color2, (int) (210 * fade)));
        g.fill(new Ellipse2D.Double(x + w * 0.18, y + h * 0.18, w * 0.64, h * 0.64));
        g.setColor(alpha(Color.WHITE, (int) (230 * fade)));
        g.setStroke(new BasicStroke(3f));
        g.draw(new Ellipse2D.Double(x, y, w, h));
    }

    private void drawFire(Graphics2D g) {
        double sp = Math.hypot(vx, vy);
        double ux = sp > 0.01 ? -vx / sp : 0, uy = sp > 0.01 ? -vy / sp : 0;
        double sz = Math.max(w, h);
        for (int i = 5; i >= 1; i--) {
            double tx = cx + ux * i * sz * 0.28, ty = cy + uy * i * sz * 0.28;
            double r = sz * (0.5 - i * 0.06);
            g.setColor(alpha(color, 110 - i * 16));
            g.fill(new Ellipse2D.Double(tx - r, ty - r, r * 2, r * 2));
        }
        double r = sz * 0.55;
        g.setColor(alpha(color, 110));
        g.fill(new Ellipse2D.Double(cx - r * 1.35, cy - r * 1.35, r * 2.7, r * 2.7));
        g.setColor(alpha(color, 235));
        g.fill(new Ellipse2D.Double(cx - r, cy - r, r * 2, r * 2));
        g.setColor(alpha(color2, 245));
        g.fill(new Ellipse2D.Double(cx - r * 0.62, cy - r * 0.62, r * 1.24, r * 1.24));
        g.setColor(Color.WHITE);
        g.fill(new Ellipse2D.Double(cx - r * 0.28, cy - r * 0.28, r * 0.56, r * 0.56));
    }

    private void drawPage(Graphics2D g) {
        g.translate(cx, cy);
        g.rotate(rot);
        g.setColor(alpha(color, 90));
        g.fill(new Ellipse2D.Double(-w * 0.8, -w * 0.8, w * 1.6, w * 1.6));
        g.setColor(new Color(240, 228, 200));
        g.fill(new Rectangle2D.Double(-w * 0.4, -h * 0.5, w * 0.8, h));
        g.setColor(color);
        g.setStroke(new BasicStroke(2f));
        g.draw(new Rectangle2D.Double(-w * 0.4, -h * 0.5, w * 0.8, h));
        g.draw(new Line2D.Double(-w * 0.25, -h * 0.2, w * 0.25, -h * 0.2));
        g.draw(new Line2D.Double(-w * 0.25, 0, w * 0.25, 0));
        g.draw(new Line2D.Double(-w * 0.25, h * 0.2, w * 0.1, h * 0.2));
    }

    private void drawSword(Graphics2D g) {
        g.translate(cx, cy);
        g.rotate(rot);
        double L = w;
        g.setColor(alpha(color2, 80));
        g.fill(new Ellipse2D.Double(-L * 0.6, -L * 0.3, L * 1.2, L * 0.6));
        Path2D.Double blade = new Path2D.Double();
        blade.moveTo(-L * 0.1, -h * 0.18);
        blade.lineTo(L * 0.5, 0);
        blade.lineTo(-L * 0.1, h * 0.18);
        blade.closePath();
        g.setColor(new Color(228, 240, 255));
        g.fill(blade);
        g.setColor(color);
        g.setStroke(new BasicStroke(2f));
        g.draw(blade);
        g.setColor(new Color(235, 185, 60));
        g.fill(new Rectangle2D.Double(-L * 0.14, -h * 0.5, L * 0.05, h));
        g.setColor(new Color(110, 70, 40));
        g.fill(new Rectangle2D.Double(-L * 0.5, -h * 0.07, L * 0.36, h * 0.14));
    }

    private void drawBeam(Graphics2D g, float fade, long tick) {
        double x = cx - w / 2, y = cy - h / 2;
        double flick = 0.85 + 0.15 * Math.sin(tick * 1.3);
        g.setPaint(new GradientPaint(0f, (float) y, alpha(color, 0),
                0f, (float) (y + h / 2), alpha(color, (int) (210 * fade * flick)), true));
        g.fill(new Rectangle2D.Double(x, y, w, h));
        g.setColor(alpha(color2, (int) (240 * fade * flick)));
        g.fill(new Rectangle2D.Double(x, y + h * 0.3, w, h * 0.4));
        g.setColor(alpha(Color.WHITE, (int) (255 * fade)));
        g.fill(new Rectangle2D.Double(x, y + h * 0.43, w, h * 0.14));
    }

    private void drawSlash(Graphics2D g) {
        double prog = life / (double) Math.max(1, maxLife);
        double rx = w * 0.62, ry = h * 0.62;
        double ccx = cx - dir * w * 0.3;
        double start = dir > 0 ? -65 : 115;
        Arc2D arc = new Arc2D.Double(ccx - rx, cy - ry, rx * 2, ry * 2, start, 130, Arc2D.OPEN);
        g.setStroke(new BasicStroke((float) (6 + 14 * prog), BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.setColor(alpha(new Color(120, 190, 255), (int) (110 * prog + 40)));
        g.draw(arc);
        g.setStroke(new BasicStroke((float) (3 + 6 * prog), BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.setColor(alpha(Color.WHITE, (int) (255 * Math.min(1, prog + 0.3))));
        g.draw(arc);
    }

    private void drawSolar(Graphics2D g, float fade) {
        double x = cx - w / 2, y = cy - h / 2;
        g.setColor(alpha(color, (int) (55 * fade)));
        g.fill(new Ellipse2D.Double(cx - w * 0.6, cy - h * 0.7, w * 1.2, h * 1.4));
        Area cres = new Area(new Ellipse2D.Double(x, y, w, h));
        double off = dir * w * 0.28;
        cres.subtract(new Area(new Ellipse2D.Double(x - off, y + h * 0.02, w * 0.95, h * 0.96)));
        g.setPaint(new GradientPaint((float) x, (float) y, alpha(new Color(255, 250, 200), (int) (245 * fade)),
                (float) (x + w), (float) (y + h), alpha(color, (int) (225 * fade))));
        g.fill(cres);
        g.setColor(alpha(Color.WHITE, (int) (230 * fade)));
        g.setStroke(new BasicStroke(3f));
        g.draw(cres);
        g.setColor(alpha(new Color(255, 230, 120), (int) (200 * fade)));
        g.setStroke(new BasicStroke(3f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        for (int i = 0; i < 9; i++) {
            double a = (-0.9 + i * 0.225) * (dir > 0 ? 1 : -1) + (dir > 0 ? 0 : Math.PI);
            double r1 = w * 0.55, r2 = w * (0.78 + 0.12 * (i % 2));
            g.draw(new Line2D.Double(cx - dir * w * 0.25 + Math.cos(a) * r1, cy + Math.sin(a) * r1 * 0.9,
                    cx - dir * w * 0.25 + Math.cos(a) * r2, cy + Math.sin(a) * r2 * 0.9));
        }
    }

    private void drawColumn(Graphics2D g) {
        double prog = 1.0 - life / (double) Math.max(1, maxLife);
        double ww2 = w * (1.0 - 0.35 * prog);
        double x = cx - ww2 / 2, y = cy - h / 2;
        g.setPaint(new GradientPaint((float) x, 0f, alpha(color, 130), (float) (x + ww2 / 2), 0f, alpha(color2, 240), true));
        g.fill(new RoundRectangle2D.Double(x, y, ww2, h, ww2 * 0.6, ww2 * 0.6));
        g.setColor(alpha(Color.WHITE, 170));
        g.fill(new Ellipse2D.Double(cx - ww2 * 0.75, y - 6, ww2 * 1.5, 18));
        g.setColor(alpha(Color.WHITE, 120));
        g.setStroke(new BasicStroke(2f));
        g.draw(new Line2D.Double(cx - ww2 * 0.15, y + 14, cx - ww2 * 0.15, y + h - 6));
    }

    private void drawAxe(Graphics2D g) {
        g.translate(cx, cy);
        g.rotate(rot);
        double s = w;
        g.setColor(alpha(color, 90));
        g.fill(new Ellipse2D.Double(-s * 0.7, -s * 0.7, s * 1.4, s * 1.4));
        g.setColor(new Color(90, 70, 50));
        g.fill(new Rectangle2D.Double(-s * 0.5, -4, s, 8));
        Path2D.Double blade = new Path2D.Double();
        blade.moveTo(s * 0.05, -s * 0.1);
        blade.quadTo(s * 0.62, -s * 0.55, s * 0.5, s * 0.05);
        blade.quadTo(s * 0.55, s * 0.5, s * 0.05, s * 0.12);
        blade.closePath();
        g.setColor(new Color(70, 110, 80));
        g.fill(blade);
        g.setColor(color2);
        g.setStroke(new BasicStroke(3f));
        g.draw(blade);
    }
}
