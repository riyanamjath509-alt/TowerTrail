import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/** Loads images from the "assets" folder and caches scaled / flipped copies. */
public class Assets {
    private static final Map<String, BufferedImage> raw = new HashMap<String, BufferedImage>();
    private static final Map<String, BufferedImage> scaled = new HashMap<String, BufferedImage>();

    public static BufferedImage get(String file) {
        BufferedImage img = raw.get(file);
        if (img == null) {
            img = load(file);
            raw.put(file, img);
        }
        return img;
    }

    private static boolean warned = false;

    private static BufferedImage load(String file) {
        try {
            // 1) on the classpath (IntelliJ copies src/assets next to the compiled classes)
            InputStream in = Assets.class.getResourceAsStream("/assets/" + file);
            if (in != null) {
                BufferedImage img = ImageIO.read(in);
                in.close();
                if (img != null) return img;
            }
            // 2) as plain files, near the working directory or the compiled classes
            java.util.List<File> bases = new java.util.ArrayList<File>();
            bases.add(new File(System.getProperty("user.dir", ".")));
            try {
                File code = new File(Assets.class.getProtectionDomain().getCodeSource().getLocation().toURI());
                bases.add(code.isDirectory() ? code : code.getParentFile());
            } catch (Exception ignore) {
            }
            for (File base : bases) {
                File dir = base;
                for (int up = 0; up < 5 && dir != null; up++) {
                    String[] rel = {"assets/", "src/assets/", "TowerTrail/assets/", "TowerTrail/src/assets/"};
                    for (String r : rel) {
                        File f = new File(dir, r + file);
                        if (f.exists()) {
                            BufferedImage img = ImageIO.read(f);
                            if (img != null) return img;
                        }
                    }
                    dir = dir.getParentFile();
                }
            }
        } catch (Exception e) {
            System.err.println("Could not load " + file + ": " + e);
        }
        if (!warned) {
            warned = true;
            System.err.println("NOTE: image files not found (looked for assets/" + file + "). "
                    + "Using the built-in drawn skins instead. Keep the 'assets' folder inside 'src' to use the real art.");
        }
        return Fallback.make(file);
    }

    public static BufferedImage byHeight(String file, int height, boolean flip, boolean white) {
        BufferedImage src = get(file);
        int w = Math.max(1, (int) Math.round(src.getWidth() * (height / (double) src.getHeight())));
        return make(file, w, height, flip, white);
    }

    public static BufferedImage byScale(String file, double scale, boolean flip, boolean white) {
        BufferedImage src = get(file);
        int w = Math.max(1, (int) Math.round(src.getWidth() * scale));
        int h = Math.max(1, (int) Math.round(src.getHeight() * scale));
        return make(file, w, h, flip, white);
    }

    private static BufferedImage make(String file, int w, int h, boolean flip, boolean white) {
        String key = file + "|" + w + "x" + h + "|" + flip + "|" + white;
        BufferedImage c = scaled.get(key);
        if (c != null) return c;
        BufferedImage img = resize(get(file), w, h);
        if (flip) img = flipH(img);
        if (white) img = whiten(img);
        scaled.put(key, img);
        return img;
    }

    private static BufferedImage resize(BufferedImage src, int w, int h) {
        BufferedImage cur = src;
        int cw = cur.getWidth(), ch = cur.getHeight();
        while (cw / 2 >= w && ch / 2 >= h) {
            cw /= 2;
            ch /= 2;
            cur = draw(cur, cw, ch);
        }
        return draw(cur, w, h);
    }

    private static BufferedImage draw(BufferedImage s, int w, int h) {
        BufferedImage out = new BufferedImage(Math.max(1, w), Math.max(1, h), BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = out.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g.drawImage(s, 0, 0, out.getWidth(), out.getHeight(), null);
        g.dispose();
        return out;
    }

    private static BufferedImage flipH(BufferedImage s) {
        BufferedImage out = new BufferedImage(s.getWidth(), s.getHeight(), BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = out.createGraphics();
        g.drawImage(s, s.getWidth(), 0, -s.getWidth(), s.getHeight(), null);
        g.dispose();
        return out;
    }

    private static BufferedImage whiten(BufferedImage s) {
        BufferedImage out = new BufferedImage(s.getWidth(), s.getHeight(), BufferedImage.TYPE_INT_ARGB);
        for (int y = 0; y < s.getHeight(); y++) {
            for (int x = 0; x < s.getWidth(); x++) {
                int a = s.getRGB(x, y) >>> 24;
                out.setRGB(x, y, (a << 24) | 0xFFFFFF);
            }
        }
        return out;
    }
}
