import java.awt.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Reto - the overpowered swordsman. */
public class Player {
    public static final double MOVE = 4.7;
    public static final double BODY_W = 30, BODY_H = 74;
    public static final int[] MAXCD = {110, 220, 300, 420};
    public static final String[] SKILL_NAMES = {"Quick Charge", "Heavenly Fire Slash", "Solar Slash", "Mighty Sword Throw"};

    public double x = 140, y = GamePanel.GROUND, vx, vy;
    public int hp, maxHp = 220;
    public int facing = 1;
    public boolean onGround;
    public int jumps;
    public String mood = "player_portrait.png";
    public int moodT;
    public int parryT, parryCd, parryFlash;
    public int attackTimer, attackCd, invuln, dashTimer, hurtFlash, stun, animTick, dropTimer;
    public int[] cd = new int[4];
    public boolean[] unlocked = new boolean[4];
    private Set<Enemy> dashHit = new HashSet<Enemy>();
    private List<double[]> ghosts = new ArrayList<double[]>(); // x, y, facing, life

    public Player() {
        hp = maxHp;
    }

    public void setMood(String file, int frames) {
        mood = file;
        moodT = frames;
    }

    /** Face shown in the HUD: reacts to what is happening. */
    public String portrait() {
        if (moodT > 0) return mood;
        if (hp < maxHp * 0.3) return "player_angry.png";
        return "player_portrait.png";
    }

    public boolean parrying() {
        return parryT > 0;
    }

    /** Area in front of Reto that catches attacks while parrying. */
    public Rectangle2D.Double parryBox() {
        double bx = facing > 0 ? x - 25 : x - 85;
        return new Rectangle2D.Double(bx, y - 90, 110, 95);
    }

    public void onParry(GamePanel g) {
        parryFlash = 14;
        invuln = Math.max(invuln, 25);
        hp = Math.min(maxHp, hp + 3);
        setMood("player_happy.png", 40);
        g.shake(5);
        g.flash(2);
        g.burst(x + facing * 55, y - 45, new Color(255, 230, 140), 18, 5);
        g.floatText("PARRY!", x, y - 100, new Color(255, 235, 150), 22);
        Sfx.parry();
    }

    public Rectangle2D.Double box() {
        return new Rectangle2D.Double(x - BODY_W / 2, y - BODY_H, BODY_W, BODY_H);
    }

    public void resetForLevel() {
        x = 140;
        y = GamePanel.GROUND;
        vx = vy = 0;
        hp = maxHp;
        invuln = 90;
        dashTimer = attackTimer = attackCd = stun = hurtFlash = 0;
        facing = 1;
        for (int i = 0; i < 4; i++) cd[i] = 0;
        dashHit.clear();
        ghosts.clear();
    }

    public void update(GamePanel g) {
        animTick++;
        if (moodT > 0) moodT--;
        if (parryT > 0) parryT--;
        if (parryCd > 0) parryCd--;
        if (parryFlash > 0) parryFlash--;
        if (attackTimer > 0) attackTimer--;
        if (attackCd > 0) attackCd--;
        if (invuln > 0) invuln--;
        if (hurtFlash > 0) hurtFlash--;
        if (dropTimer > 0) dropTimer--;
        if (stun > 0) stun--;
        for (int i = 0; i < 4; i++) if (cd[i] > 0) cd[i]--;
        for (int i = ghosts.size() - 1; i >= 0; i--) {
            double[] gh = ghosts.get(i);
            gh[3]--;
            if (gh[3] <= 0) ghosts.remove(i);
        }

        // ---------- actions
        if (g.jumpPressed) {
            g.jumpPressed = false;
            if (g.down && onGround && y < GamePanel.GROUND - 1) {
                dropTimer = 14;           // drop through a platform
                y += 3;
                onGround = false;
                jumps = 1;
            } else if (dashTimer <= 0 && stun <= 0) {
                if (!onGround && jumps == 0) jumps = 1;
                if (jumps < 2) {
                    vy = (jumps == 0) ? -12.8 : -11.6;
                    jumps++;
                    onGround = false;
                    Sfx.jump();
                    g.burst(x, y, new Color(220, 230, 255), 6, 2.5);
                }
            }
        }
        if (g.parryPressed) {
            g.parryPressed = false;
            if (parryCd <= 0 && dashTimer <= 0 && stun <= 0 && attackTimer <= 0) {
                parryT = 16;      // the parry window
                parryCd = 42;     // short cooldown (so spamming is punished)
                Sfx.dash();
            }
        }
        if (g.attackPressed) {
            g.attackPressed = false;
            if (attackCd <= 0 && dashTimer <= 0 && stun <= 0 && parryT <= 0) {
                attackTimer = 12;
                attackCd = 17;
                Hazard hz = new Hazard(Hazard.SLASH, x + facing * 52, y - 42, 120, 96, 16, 0, 9, new Color(230, 245, 255));
                hz.friendly = true;
                hz.dir = facing;
                g.addHazard(hz);
                Sfx.slash();
            }
        }
        for (int i = 0; i < 4; i++) {
            if (g.skillPressed[i]) {
                g.skillPressed[i] = false;
                if (!unlocked[i]) {
                    g.toast("Locked! Defeat the Floor " + (i + 1) + " boss to unlock " + SKILL_NAMES[i]);
                } else if (cd[i] <= 0 && dashTimer <= 0 && stun <= 0) {
                    cast(i, g);
                }
            }
        }

        // ---------- movement
        double prevY = y;
        if (dashTimer > 0) {
            dashTimer--;
            vx = facing * 15;
            vy = 0;
            invuln = Math.max(invuln, 3);
            if (animTick % 2 == 0) ghosts.add(new double[]{x, y, facing, 14});
            for (Enemy e : g.enemies) {
                if (!e.canBeHit() || dashHit.contains(e)) continue;
                if (box().intersects(e.hitbox())) {
                    dashHit.add(e);
                    e.damage(42, g, x);
                    g.shake(5);
                }
            }
            if (dashTimer == 0) {
                dashHit.clear();
                vx = 0;
            }
        } else {
            if (stun > 0) {
                vx *= 0.9;
            } else if (g.left && !g.right) {
                vx = -MOVE;
                facing = -1;
            } else if (g.right && !g.left) {
                vx = MOVE;
                facing = 1;
            } else {
                vx *= 0.55;
            }
            if (parryT > 0) vx *= 0.35;
            vy += GamePanel.GRAV;
        }
        x += vx;
        if (x < 20) x = 20;
        if (x > GamePanel.W - 20) x = GamePanel.W - 20;
        y += vy;
        onGround = false;
        if (y >= GamePanel.GROUND) {
            y = GamePanel.GROUND;
            vy = 0;
            onGround = true;
        } else if (vy >= 0 && dropTimer <= 0) {
            for (Rectangle p : g.platforms) {
                if (prevY <= p.y + 2 && y >= p.y && x + 10 > p.x && x - 10 < p.x + p.width) {
                    y = p.y;
                    vy = 0;
                    onGround = true;
                    break;
                }
            }
        }
        if (onGround) jumps = 0;
    }

    private void cast(int i, GamePanel g) {
        cd[i] = MAXCD[i];
        attackTimer = 14;
        setMood("player_angry.png", 50);
        switch (i) {
            case 0: { // Quick Charge
                dashTimer = 14;
                dashHit.clear();
                g.shake(4);
                Sfx.dash();
                break;
            }
            case 1: { // Heavenly Fire Slash
                Hazard hz = new Hazard(Hazard.FIRE, x + facing * 44, y - 46, 96, 96, 55, 0, 80, new Color(255, 110, 20));
                hz.color2 = new Color(255, 230, 120);
                hz.vx = facing * 9.5;
                hz.dir = facing;
                hz.friendly = true;
                hz.hitScale = 0.9;
                g.addHazard(hz);
                g.burst(x + facing * 40, y - 46, new Color(255, 160, 40), 18, 5);
                g.shake(5);
                Sfx.skill();
                break;
            }
            case 2: { // Solar Slash
                Hazard hz = new Hazard(Hazard.SOLAR, x + facing * 115, y - 80, 290, 220, 80, 0, 16, new Color(255, 200, 40));
                hz.dir = facing;
                hz.friendly = true;
                g.addHazard(hz);
                g.flash(10);
                g.shake(9);
                g.burst(x + facing * 110, y - 80, new Color(255, 225, 100), 30, 7);
                Sfx.skill();
                break;
            }
            default: { // Mighty Sword Throw
                Hazard hz = new Hazard(Hazard.SWORD, x, y - 50, 130, 38, 38, 0, 120, new Color(110, 180, 255));
                hz.color2 = new Color(170, 220, 255);
                hz.vx = facing * 17;
                hz.rotSpeed = 0.45 * facing;
                hz.boomerangAt = 44;
                hz.homeBack = true;
                hz.owner = this;
                hz.rehit = 7;
                hz.friendly = true;
                g.addHazard(hz);
                g.shake(4);
                Sfx.skill();
                break;
            }
        }
    }

    public boolean hurt(int dmg, double fromX, GamePanel g) {
        if (invuln > 0 || hp <= 0) return false;
        hp -= dmg;
        if (hp < 0) hp = 0;
        invuln = 55;
        hurtFlash = 10;
        stun = 10;
        setMood("player_surprised.png", 50);
        vx = (x < fromX ? -1 : 1) * 6;
        vy = -6;
        g.shake(7);
        g.burst(x, y - 40, new Color(255, 80, 80), 12, 4);
        g.floatText("-" + dmg, x, y - 90, new Color(255, 90, 90), 20);
        Sfx.hurt();
        return true;
    }

    // ------------------------------------------------------------------ drawing
    public void draw(Graphics2D g) {
        boolean flip = facing == -1;
        // afterimages of Quick Charge
        for (double[] gh : ghosts) {
            Composite old = g.getComposite();
            g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, (float) (gh[3] / 14.0 * 0.45)));
            BufferedImage img = Assets.byScale("player_run.png", 0.62, gh[2] < 0, false);
            g.drawImage(img, (int) (gh[0] - img.getWidth() / 2.0), (int) (gh[1] - img.getHeight()), null);
            g.setComposite(old);
        }
        // shadow
        g.setColor(new Color(0, 0, 0, 70));
        g.fillOval((int) x - 20, (int) y - 4, 40, 8);

        Composite old = g.getComposite();
        float al = 1f;
        if (invuln > 0 && hurtFlash == 0 && dashTimer <= 0 && (invuln / 4) % 2 == 0) al = 0.45f;
        g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, al));
        String n;
        double sc;
        if (dashTimer > 0 || attackTimer > 0) {
            n = "player_attack.png";
            sc = 0.42;
        } else {
            sc = 0.62;
            if (!onGround) n = vy < 0 ? "player_jump.png" : "player_fall.png";
            else if (Math.abs(vx) > 1) n = ((animTick / 7) % 2 == 0) ? "player_walk.png" : "player_run.png";
            else n = "player_idle.png";
        }
        BufferedImage img = Assets.byScale(n, sc, flip, false);
        int dx = (int) (x - img.getWidth() / 2.0);
        int dy = (int) (y - img.getHeight() + 4);
        g.drawImage(img, dx, dy, null);
        if (hurtFlash > 0) {
            g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.6f));
            g.drawImage(Assets.byScale(n, sc, flip, true), dx, dy, null);
        }
        g.setComposite(old);

        // parry shield
        if (parryT > 0 || parryFlash > 0) {
            Stroke os = g.getStroke();
            float a = parryFlash > 0 ? 1f : 0.45f + 0.55f * parryT / 16f;
            double r = parryFlash > 0 ? 58 + (14 - parryFlash) * 2.5 : 50;
            double cx = x + facing * 20, cy = y - 42;
            g.setColor(new Color(130, 210, 255, (int) (60 * a)));
            g.fill(new Ellipse2D.Double(cx - r, cy - r, r * 2, r * 2));
            double start = facing > 0 ? -80 : 100;
            Arc2D arc = new Arc2D.Double(cx - r, cy - r, r * 2, r * 2, start, 160, Arc2D.OPEN);
            g.setStroke(new BasicStroke(8f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g.setColor(new Color(120, 200, 255, (int) (150 * a)));
            g.draw(arc);
            g.setStroke(new BasicStroke(3f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g.setColor(new Color(255, 255, 255, (int) (255 * a)));
            g.draw(arc);
            g.setStroke(os);
        }
    }
}
