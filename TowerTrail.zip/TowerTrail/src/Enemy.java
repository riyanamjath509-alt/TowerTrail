import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.util.Random;

/** Minions and bosses. Bosses use a small attack state machine; minions use simple behaviours. */
public class Enemy {
    public static final int B_RUSH = 0, B_SHOOT = 1, B_LEAP = 2, B_FLY = 3, B_CHARGE = 4;
    private static final Random R = new Random();

    /** One boss attack: id picks the behaviour, name is shown to the player. */
    public static class Atk {
        public final String id, name;
        public final int windup, shape;
        public final Color col;

        public Atk(String id, String name, int windup, Color col, int shape) {
            this.id = id;
            this.name = name;
            this.windup = windup;
            this.col = col;
            this.shape = shape;
        }
    }

    public double x, y, vx, vy, kvx, speed = 2, dashSpeed = 9, alpha = 1.0;
    public int w = 50, h = 60, hp = 50, maxHp = 50, behavior, spriteH = 80, contactDmg = 10, facing = -1;
    public int timer, state, hurtFlash, age, spawnT, exec, phase = 1, level, introT, deathTimer;
    public int shootCd = 90, shotCount = 1, shotShape = Hazard.FIRE;
    public double shotSpeed = 5;
    public Color shotCol = new Color(255, 140, 30), shotCol2 = new Color(255, 230, 120);
    public String name = "", title = "", sprite = "m1a.png";
    public boolean nativeLeft = true, boss, flying, onGround, removed, dying;
    public Atk[] atks;
    public Atk cur, lastAtk;
    public String atkSprite;
    public int atkT;

    public Rectangle2D.Double hitbox() {
        return new Rectangle2D.Double(x - w / 2.0, y - h, w, h);
    }

    public boolean canBeHit() {
        return !dying && !removed && alpha > 0.6 && spawnT <= 0 && introT <= 0;
    }

    public boolean canHurtPlayer() {
        return !dying && !removed && alpha > 0.6 && spawnT <= 0 && introT <= 0 && contactDmg > 0;
    }

    static int minionTypes(int level) {
        int[] n = {1, 2, 3, 3, 4};
        return n[level];
    }

    // ------------------------------------------------------------------ factories
    public static Enemy minion(int level, int type) {
        Enemy e = new Enemy();
        e.level = level;
        switch (level) {
            case 0: // Iglugat
                e.name = "Iglugat"; e.sprite = "m1a.png"; e.spriteH = 76; e.w = 64; e.h = 46;
                e.hp = 45; e.speed = 3.0; e.behavior = B_LEAP; e.contactDmg = 10; e.nativeLeft = true;
                break;
            case 1:
                if (type == 0) { // Ibol
                    e.name = "Ibol"; e.sprite = "m2a.png"; e.spriteH = 96; e.w = 58; e.h = 80;
                    e.hp = 60; e.speed = 2.1; e.behavior = B_RUSH; e.contactDmg = 12;
                } else {         // Bokbol (fire)
                    e.name = "Bokbol"; e.sprite = "m2b.png"; e.spriteH = 96; e.w = 58; e.h = 80;
                    e.hp = 50; e.speed = 1.6; e.behavior = B_SHOOT; e.contactDmg = 8;
                    e.shootCd = 80; e.shotSpeed = 5.6; e.shotCol = new Color(255, 90, 20);
                }
                break;
            case 2:
                if (type == 0) {         // Bushi
                    e.name = "Bushi"; e.sprite = "m3a.png"; e.spriteH = 100; e.w = 56; e.h = 84;
                    e.hp = 70; e.speed = 3.2; e.behavior = B_RUSH; e.contactDmg = 12;
                } else if (type == 1) {  // Flora
                    e.name = "Flora"; e.sprite = "m3b.png"; e.spriteH = 108; e.w = 52; e.h = 90;
                    e.hp = 55; e.speed = 1.4; e.behavior = B_SHOOT; e.contactDmg = 8;
                    e.shootCd = 100; e.shotCount = 3; e.shotSpeed = 4.8; e.shotShape = Hazard.PAGE;
                    e.shotCol = new Color(220, 70, 180); e.shotCol2 = new Color(255, 160, 230);
                } else {                 // Tros
                    e.name = "Tros"; e.sprite = "m3c.png"; e.spriteH = 92; e.w = 56; e.h = 76;
                    e.hp = 80; e.speed = 1.8; e.behavior = B_CHARGE; e.contactDmg = 14; e.dashSpeed = 8.5;
                }
                break;
            case 3:
                if (type == 0) {         // Spear Golar
                    e.name = "Spear Golar"; e.sprite = "m4a.png"; e.spriteH = 124; e.w = 80; e.h = 108;
                    e.hp = 95; e.speed = 2.1; e.behavior = B_RUSH; e.contactDmg = 14;
                } else if (type == 1) {  // Flying Golar
                    e.name = "Flying Golar"; e.sprite = "m4b.png"; e.spriteH = 100; e.w = 80; e.h = 60;
                    e.hp = 60; e.speed = 1.7; e.behavior = B_FLY; e.flying = true; e.contactDmg = 8;
                    e.shootCd = 85; e.shotSpeed = 6.2; e.shotCol = new Color(60, 220, 110); e.shotCol2 = new Color(200, 255, 200);
                } else {                 // Sword Golar
                    e.name = "Sword Golar"; e.sprite = "m4c.png"; e.spriteH = 118; e.w = 66; e.h = 104;
                    e.hp = 100; e.speed = 2.0; e.behavior = B_CHARGE; e.contactDmg = 16; e.dashSpeed = 9;
                }
                break;
            default:
                if (type == 0) {         // Blue Eel
                    e.name = "Blue Eel"; e.sprite = "m5a.png"; e.spriteH = 92; e.w = 70; e.h = 70;
                    e.hp = 70; e.speed = 2.6; e.behavior = B_CHARGE; e.contactDmg = 14; e.dashSpeed = 11;
                } else if (type == 1) {  // Dragon Scale Snake
                    e.name = "Dragon Scale Snake"; e.sprite = "m5b.png"; e.spriteH = 96; e.w = 74; e.h = 76;
                    e.hp = 120; e.speed = 1.5; e.behavior = B_CHARGE; e.contactDmg = 18; e.dashSpeed = 8;
                } else if (type == 2) {  // Lizard
                    e.name = "Lizard"; e.sprite = "m5c.png"; e.spriteH = 88; e.w = 72; e.h = 60;
                    e.hp = 80; e.speed = 3.2; e.behavior = B_LEAP; e.contactDmg = 14;
                } else {                 // Twin Headed Eel
                    e.name = "Twin Headed Eel"; e.sprite = "m5d.png"; e.spriteH = 100; e.w = 70; e.h = 80;
                    e.hp = 90; e.speed = 1.6; e.behavior = B_SHOOT; e.contactDmg = 10; e.nativeLeft = false;
                    e.shootCd = 95; e.shotCount = 2; e.shotSpeed = 5.8;
                    e.shotCol = new Color(90, 120, 255); e.shotCol2 = new Color(200, 220, 255);
                }
                break;
        }
        if (level == 0 || (level == 4 && type != 3)) e.nativeLeft = true;
        String base = e.sprite.substring(0, e.sprite.length() - 4);
        String[] hasAtk = {"m3a", "m3b", "m3c", "m4a", "m4b", "m4c", "m5a", "m5d"};
        for (String k : hasAtk) if (k.equals(base)) e.atkSprite = base + "_atk.png";
        e.maxHp = e.hp;
        e.timer = 40 + R.nextInt(40);
        return e;
    }

    public static Enemy boss(int level) {
        Enemy e = new Enemy();
        e.level = level;
        e.boss = true;
        e.name = Levels.BOSS_NAMES[level];
        e.title = Levels.BOSS_TITLES[level];
        e.introT = 80;
        e.timer = 70;
        Color green = new Color(120, 200, 70);
        switch (level) {
            case 0: // Iglugon
                e.sprite = "boss1.png"; e.spriteH = 230; e.w = 200; e.h = 140; e.hp = 480; e.speed = 1.9; e.contactDmg = 16;
                e.dashSpeed = 10;
                e.atks = new Atk[]{
                        new Atk("pounce", "Pounce!", 26, green, Hazard.FIRE),
                        new Atk("claw", "Claw Swipe", 22, green, Hazard.RECT),
                        new Atk("charge", "Rampage Charge", 34, green, Hazard.RECT),
                        new Atk("summon", "Pack Call!", 30, green, Hazard.RECT)};
                break;
            case 1: // BoBkuBo
                e.sprite = "boss2.png"; e.spriteH = 300; e.w = 140; e.h = 230; e.hp = 800; e.speed = 1.4; e.contactDmg = 14;
                e.atks = new Atk[]{
                        new Atk("proj", "Magic Blast", 30, new Color(170, 90, 255), Hazard.PAGE),
                        new Atk("ring", "Page Circle", 36, new Color(190, 120, 255), Hazard.PAGE),
                        new Atk("teleport", "Teleport", 20, new Color(150, 90, 230), Hazard.RECT),
                        new Atk("rain", "Book Storm", 40, new Color(170, 90, 255), Hazard.PAGE)};
                break;
            case 2: // Teon
                e.sprite = "boss3.png"; e.spriteH = 350; e.w = 190; e.h = 290; e.hp = 1100; e.speed = 0.8; e.contactDmg = 18;
                e.atks = new Atk[]{
                        new Atk("shock", "Branch Slam", 34, new Color(150, 110, 50), Hazard.RECT),
                        new Atk("sweep", "Tentacle Strike", 28, new Color(110, 170, 60), Hazard.RECT),
                        new Atk("burst", "Fire Burst", 36, new Color(255, 120, 20), Hazard.OVAL),
                        new Atk("geyser", "Root Trap", 34, new Color(120, 90, 40), Hazard.COLUMN),
                        new Atk("beam", "Solar Eye Blast", 44, new Color(255, 150, 20), Hazard.BEAM)};
                break;
            case 3: // Golar
                e.sprite = "boss4.png"; e.spriteH = 350; e.w = 200; e.h = 300; e.hp = 1400; e.speed = 0.9; e.contactDmg = 20;
                e.atks = new Atk[]{
                        new Atk("shock", "Axe Smash", 36, new Color(80, 240, 120), Hazard.RECT),
                        new Atk("sweep", "Tentacle Sweep", 28, new Color(60, 180, 120), Hazard.RECT),
                        new Atk("geyser", "Sea Surge", 34, new Color(60, 190, 230), Hazard.COLUMN),
                        new Atk("throw", "Axe Throw", 32, new Color(90, 230, 140), Hazard.AXE),
                        new Atk("beam", "Green Eye Beam", 46, new Color(80, 255, 120), Hazard.BEAM)};
                break;
            default: // Grodre
                e.sprite = "boss5.png"; e.spriteH = 330; e.w = 190; e.h = 260; e.hp = 1900; e.speed = 1.3; e.contactDmg = 22;
                e.atks = new Atk[]{
                        new Atk("proj", "Hell Fire Breath", 34, new Color(255, 90, 20), Hazard.FIRE),
                        new Atk("shock", "Wing Slam", 36, new Color(255, 70, 40), Hazard.RECT),
                        new Atk("sweep", "Tail Sweep", 28, new Color(230, 50, 50), Hazard.RECT),
                        new Atk("dive", "Meteor Dive", 30, new Color(255, 120, 30), Hazard.OVAL),
                        new Atk("rain", "Dark Storm", 40, new Color(255, 100, 30), Hazard.FIRE),
                        new Atk("summon", "Summon Minions", 32, new Color(200, 40, 60), Hazard.RECT)};
                break;
        }
        e.maxHp = e.hp;
        return e;
    }

    // ------------------------------------------------------------------ damage
    public boolean damage(int dmg, GamePanel g, double fromX) {
        if (!canBeHit() || hp <= 0) return false;
        hp -= dmg;
        hurtFlash = 5;
        g.floatText(String.valueOf(dmg), x + (R.nextDouble() - 0.5) * 30, y - h, new Color(255, 240, 150), 18);
        g.burst(x, y - h * 0.5, boss ? new Color(255, 220, 160) : Color.WHITE, 6, 3.5);
        if (!boss) kvx = (x < fromX ? -1 : 1) * 5;
        Sfx.hit();
        if (hp <= 0) {
            hp = 0;
            dying = true;
            deathTimer = boss ? 90 : 14;
            if (boss) {
                g.flash(14);
                Sfx.boom();
            }
        }
        return true;
    }

    // ------------------------------------------------------------------ update
    public void update(GamePanel g) {
        age++;
        if (atkT > 0) atkT--;
        if (hurtFlash > 0) hurtFlash--;
        if (dying) {
            deathTimer--;
            if (boss) {
                if (deathTimer % 4 == 0) {
                    g.burst(x + (R.nextDouble() - 0.5) * w, y - R.nextDouble() * h, new Color(255, 200, 90), 14, 6);
                }
                if (deathTimer % 12 == 0) g.shake(9);
            }
            if (deathTimer <= 0) {
                removed = true;
                g.onEnemyDeath(this);
            }
            return;
        }
        if (boss) updateBoss(g);
        else updateMinion(g);
    }

    private void updateMinion(GamePanel g) {
        Player p = g.player;
        double dx = p.x - x;
        int dir = dx < 0 ? -1 : 1;
        if (spawnT > 0) {
            spawnT--;
            facing = x < GamePanel.W / 2.0 ? 1 : -1;
            x += facing * 2.6;
            return;
        }
        x += kvx;
        kvx *= 0.85;
        switch (behavior) {
            case B_RUSH:
                facing = dir;
                if (Math.abs(dx) > 26) x += dir * speed;
                if (Math.abs(dx) < 75) atkT = 3;
                break;
            case B_SHOOT: {
                facing = dir;
                double ad = Math.abs(dx);
                if (ad < 250) x -= dir * speed;
                else if (ad > 400) x += dir * speed;
                if (--timer <= 0) {
                    timer = shootCd + R.nextInt(40);
                    fire(g);
                }
                break;
            }
            case B_LEAP:
                facing = dir;
                if (onGround) {
                    if (Math.abs(dx) > 30) x += dir * speed * 0.55;
                    if (--timer <= 0 && Math.abs(dx) < 420) {
                        vy = -11.5;
                        vx = dir * (speed * 2.0 + 2.5);
                        timer = 55 + R.nextInt(45);
                        onGround = false;
                    }
                } else {
                    x += vx;
                    atkT = 3;
                }
                break;
            case B_FLY: {
                facing = dir;
                double targetY = GamePanel.GROUND - 170 - 25 * Math.sin(age * 0.05);
                y += (targetY - y) * 0.05;
                double ad = Math.abs(dx);
                if (ad < 220) x -= dir * speed;
                else if (ad > 330) x += dir * speed;
                if (--timer <= 0) {
                    timer = shootCd + R.nextInt(40);
                    fire(g);
                }
                break;
            }
            default: // B_CHARGE
                if (state == 0) {
                    facing = dir;
                    if (Math.abs(dx) > 40) x += dir * speed;
                    if (--timer <= 0 && Math.abs(dx) < 380) {
                        state = 1;
                        timer = 34;
                    }
                } else if (state == 1) {
                    facing = dir;
                    if (--timer <= 0) {
                        state = 2;
                        timer = 30;
                        vx = dir * dashSpeed;
                    }
                } else if (state == 2) {
                    x += vx;
                    atkT = 3;
                    if (--timer <= 0) {
                        state = 3;
                        timer = 45;
                        vx = 0;
                    }
                } else if (--timer <= 0) {
                    state = 0;
                    timer = 40 + R.nextInt(40);
                }
                break;
        }
        if (x < 20) x = 20;
        if (x > GamePanel.W - 20) x = GamePanel.W - 20;
        if (!flying) {
            vy += GamePanel.GRAV;
            y += vy;
            if (y >= GamePanel.GROUND) {
                y = GamePanel.GROUND;
                vy = 0;
                if (!onGround && behavior == B_LEAP) vx = 0;
                onGround = true;
            } else {
                onGround = false;
            }
        }
    }

    private void fire(GamePanel g) {
        Player p = g.player;
        double sx = x + facing * w * 0.4, sy = y - h * 0.6;
        double base = Math.atan2((p.y - 36) - sy, p.x - sx);
        for (int i = 0; i < shotCount; i++) {
            double a = base + (i - (shotCount - 1) / 2.0) * 0.25;
            Hazard hz = Hazard.shot(shotShape, sx, sy, Math.cos(a) * shotSpeed, Math.sin(a) * shotSpeed,
                    24, 9 + level * 2, shotCol, shotCol2, 220);
            hz.rotSpeed = 0.2;
            g.addHazard(hz);
        }
        atkT = 14;
        Sfx.shoot();
    }

    // ------------------------------------------------------------------ boss AI
    private void updateBoss(GamePanel g) {
        Player p = g.player;
        if (introT > 0) {
            introT--;
            facing = p.x < x ? -1 : 1;
            return;
        }
        if (phase == 1 && hp < maxHp * 0.4) {
            phase = 2;
            speed *= 1.25;
            dashSpeed *= 1.2;
            g.banner("PHASE CHANGE!", name + " grows furious!", 100);
            g.shake(16);
            g.flash(10);
        }
        switch (state) {
            case 0: {
                facing = p.x < x ? -1 : 1;
                double dx = p.x - x;
                if (Math.abs(dx) > 230) x += Math.signum(dx) * speed;
                else if (Math.abs(dx) < 110) x -= Math.signum(dx) * speed * 0.5;
                x = Math.max(w / 2.0 + 40, Math.min(GamePanel.W - w / 2.0 - 40, x));
                if (--timer <= 0) {
                    cur = atks[R.nextInt(atks.length)];
                    if (cur == lastAtk) cur = atks[R.nextInt(atks.length)];
                    lastAtk = cur;
                    state = 1;
                    timer = (int) (cur.windup * (phase == 2 ? 0.7 : 1.0));
                    g.floatText(cur.name, x, y - spriteH - 6, cur.col, 24);
                }
                break;
            }
            case 1:
                facing = p.x < x ? -1 : 1;
                if (--timer <= 0) execute(g);
                break;
            case 2:
                updateExec(g);
                break;
            default:
                if (--timer <= 0) {
                    state = 0;
                    timer = (phase == 2 ? 30 : 55) + R.nextInt(40);
                }
                break;
        }
    }

    private static Color lighter(Color c) {
        return new Color(Math.min(255, c.getRed() + 90), Math.min(255, c.getGreen() + 90), Math.min(255, c.getBlue() + 90));
    }

    private void execute(GamePanel g) {
        Player p = g.player;
        double gy = GamePanel.GROUND;
        int ph = phase;
        facing = p.x < x ? -1 : 1;
        String id = cur.id;
        state = 3;
        timer = 50;
        if (id.equals("shock")) {
            for (int d = -1; d <= 1; d += 2) {
                Hazard hz = Hazard.shot(Hazard.RECT, x + d * (w / 2.0), gy - 24, d * (6.2 + ph * 0.6), 0, 52,
                        17 + level, cur.col, lighter(cur.col), 110);
                hz.h = 46;
                hz.w = 54;
                hz.destroyOnHit = false;
                hz.groundKill = false;
                hz.hitScale = 1.0;
                g.addHazard(hz);
            }
            g.shake(10);
            g.burst(x, gy, cur.col, 20, 5);
        } else if (id.equals("sweep") || id.equals("claw")) {
            boolean small = id.equals("claw");
            double cx = x + facing * (w / 2.0 + (small ? 40 : 70));
            Hazard hz = new Hazard(Hazard.RECT, cx, gy - (small ? 50 : 62), small ? 180 : 250, small ? 100 : 124,
                    (small ? 18 : 20) + level * 2, 18, 10, cur.col);
            hz.color2 = lighter(cur.col);
            g.addHazard(hz);
            g.shake(5);
            timer = 45;
        } else if (id.equals("proj")) {
            double sx = x + facing * (w * 0.4), sy = y - h * 0.62;
            double base = Math.atan2((p.y - 40) - sy, p.x - sx);
            int n = ph == 2 ? 5 : 3;
            for (int i = 0; i < n; i++) {
                double a = base + (i - (n - 1) / 2.0) * 0.22;
                double sp = level == 4 ? 7.0 : 6.3;
                Hazard hz = Hazard.shot(cur.shape, sx, sy, Math.cos(a) * sp, Math.sin(a) * sp, level == 4 ? 40 : 30,
                        14 + level * 2, cur.col, lighter(cur.col), 200);
                hz.rotSpeed = 0.25;
                g.addHazard(hz);
            }
            Sfx.shoot();
            timer = 55;
        } else if (id.equals("ring")) {
            int n = ph == 2 ? 14 : 10;
            for (int i = 0; i < n; i++) {
                Hazard hz = Hazard.shot(cur.shape, x, y - h * 0.5, 0, 0, 28, 13, cur.col, lighter(cur.col), 70 + 200);
                hz.orbitOwner = this;
                hz.orbitAngle = Math.PI * 2 * i / n;
                hz.orbitSpin = 0.045;
                hz.orbitRadius = 130;
                hz.orbitFrames = 70;
                hz.launchSpeed = 5.5;
                hz.rotSpeed = 0.2;
                g.addHazard(hz);
            }
            timer = 90;
        } else if (id.equals("teleport")) {
            state = 2;
            exec = 0;
        } else if (id.equals("rain")) {
            int n = ph == 2 ? 11 : 8;
            for (int i = 0; i < n; i++) {
                double tx = (i == 0) ? p.x : 40 + R.nextDouble() * (GamePanel.W - 80);
                Hazard hz = Hazard.shot(cur.shape, tx, -40, 0, 11, 34, 16 + level, cur.col, lighter(cur.col), 120);
                hz.delay = 30 + R.nextInt(40);
                hz.hasWarn = true;
                hz.wx = tx - 24;
                hz.wy = gy - 10;
                hz.ww = 48;
                hz.wh = 14;
                hz.warnOval = true;
                hz.rotSpeed = 0.15;
                g.addHazard(hz);
            }
            timer = 80;
        } else if (id.equals("geyser")) {
            int n = ph == 2 ? 7 : 5;
            for (int i = 0; i < n; i++) {
                double tx = (i == 0) ? p.x : Math.max(40, Math.min(GamePanel.W - 40, p.x + (R.nextDouble() - 0.5) * 520));
                Hazard hz = new Hazard(Hazard.COLUMN, tx, gy - 95, 58, 190, 20 + level, 40 + i * 6, 24, cur.col);
                hz.color2 = lighter(cur.col);
                g.addHazard(hz);
            }
            timer = 70;
        } else if (id.equals("beam")) {
            double edge = facing < 0 ? 0 : GamePanel.W;
            double start = x + facing * (w * 0.3);
            double bw = Math.abs(edge - start);
            Hazard hz = new Hazard(Hazard.BEAM, (edge + start) / 2, gy - 42, bw, 76, 24 + level * 2, 55, 30, cur.col);
            hz.color2 = lighter(cur.col);
            g.addHazard(hz);
            timer = 90;
        } else if (id.equals("burst")) {
            Hazard hz = new Hazard(Hazard.OVAL, x, gy - 55, 470, 150, 24 + level, 38, 14, cur.col);
            hz.color2 = lighter(cur.col);
            g.addHazard(hz);
            timer = 80;
        } else if (id.equals("throw")) {
            Hazard hz = Hazard.shot(Hazard.AXE, x + facing * (w / 2.0), gy - 70, facing * 8.5, 0, 80, 26,
                    cur.col, lighter(cur.col), 130);
            hz.boomerangAt = 55;
            hz.rotSpeed = 0.35 * facing;
            hz.destroyOnHit = false;
            hz.groundKill = false;
            g.addHazard(hz);
            timer = 100;
        } else if (id.equals("dive")) {
            state = 2;
            exec = 0;
        } else if (id.equals("summon")) {
            for (int i = 0; i < 2; i++) g.spawnMinion(level, R.nextInt(minionTypes(level)), i % 2 == 0 ? -1 : 1);
            g.shake(6);
            timer = 50;
        } else if (id.equals("pounce")) {
            state = 2;
            exec = 0;
            vy = -15;
            vx = facing * (8.5 + ph * 0.8);
        } else if (id.equals("charge")) {
            state = 2;
            exec = 0;
            vx = facing * dashSpeed;
        }
    }

    private void updateExec(GamePanel g) {
        Player p = g.player;
        double gy = GamePanel.GROUND;
        exec++;
        String id = cur.id;
        if (id.equals("pounce")) {
            x += vx;
            vy += 0.7;
            y += vy;
            x = Math.max(130, Math.min(GamePanel.W - 130, x));
            if (y >= gy && vy > 0) {
                y = gy;
                vy = 0;
                vx = 0;
                for (int d = -1; d <= 1; d += 2) {
                    Hazard hz = Hazard.shot(Hazard.RECT, x + d * 60, gy - 18, d * 6, 0, 40, 14, cur.col, lighter(cur.col), 70);
                    hz.h = 34;
                    hz.destroyOnHit = false;
                    hz.groundKill = false;
                    hz.hitScale = 1.0;
                    g.addHazard(hz);
                }
                g.shake(9);
                state = 3;
                timer = 50;
            }
        } else if (id.equals("charge")) {
            x += vx;
            if (exec >= 40 || x < 130 || x > GamePanel.W - 130) {
                vx = 0;
                state = 3;
                timer = 60;
                g.shake(6);
            }
        } else if (id.equals("teleport")) {
            if (exec < 24) {
                alpha = 1 - exec / 24.0;
            } else if (exec == 24) {
                alpha = 0;
                x = Math.max(150, Math.min(GamePanel.W - 150, p.x - p.facing * 150));
                facing = p.x < x ? -1 : 1;
                Hazard hz = new Hazard(Hazard.RECT, x + facing * (w / 2.0 + 70), gy - 62, 250, 124, 24, 16, 10, cur.col);
                hz.color2 = lighter(cur.col);
                g.addHazard(hz);
            } else if (exec < 44) {
                alpha = (exec - 24) / 20.0;
            } else {
                alpha = 1;
                state = 3;
                timer = 55;
            }
        } else if (id.equals("dive")) {
            if (exec < 35) {
                y -= 17;
            } else if (exec < 85) {
                y = -400;
                x += (p.x - x) * 0.07;
            } else {
                if (exec == 85) {
                    y = -400;
                    Hazard zone = new Hazard(Hazard.OVAL, x, gy - 40, 280, 90, 30, 28, 8, cur.col);
                    zone.color2 = lighter(cur.col);
                    g.addHazard(zone);
                }
                y += (gy + 400) / 27.0;
                if (y >= gy || exec > 115) {
                    y = gy;
                    for (int d = -1; d <= 1; d += 2) {
                        Hazard hz = Hazard.shot(Hazard.RECT, x + d * 90, gy - 24, d * 7, 0, 52, 20, cur.col, lighter(cur.col), 100);
                        hz.h = 46;
                        hz.destroyOnHit = false;
                        hz.groundKill = false;
                        hz.hitScale = 1.0;
                        g.addHazard(hz);
                    }
                    g.shake(16);
                    Sfx.boom();
                    state = 3;
                    timer = 80;
                }
            }
        } else {
            state = 3;
            timer = 40;
        }
    }

    // ------------------------------------------------------------------ drawing
    public void draw(Graphics2D g, long tick) {
        if (removed) return;
        boolean useAtk = atkSprite != null && atkT > 0 && !dying;
        String sp = useAtk ? atkSprite : sprite;
        boolean flip = useAtk ? facing == -1 : (nativeLeft ? facing == 1 : facing == -1);
        BufferedImage img = Assets.byHeight(sp, spriteH, flip, false);
        int dw = img.getWidth(), dh = img.getHeight();
        double bob = (boss && level == 1) ? -10 - 8 * Math.sin(age * 0.08) : 0;
        double dx = x - dw / 2.0, dy = y - dh + bob;

        if (y > 0 && y <= GamePanel.GROUND + 1) { // shadow
            g.setColor(new Color(0, 0, 0, 80));
            int sw = (int) (Math.min(dw, w + 60) * 0.8);
            g.fillOval((int) (x - sw / 2.0), GamePanel.GROUND - 6, sw, 12);
        }

        Composite old = g.getComposite();
        float al = (float) Math.max(0, Math.min(1, alpha));
        if (dying) {
            if (boss) al *= ((deathTimer / 3) % 2 == 0) ? 0.5f : 0.9f;
            else al *= Math.max(0f, deathTimer / 14f);
        }
        if (boss && phase == 2 && !dying) { // angry aura
            g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.18f + 0.1f * (float) Math.sin(age * 0.2)));
            g.setColor(new Color(255, 40, 40));
            g.fillOval((int) (x - w * 0.9), (int) (y - h - 20 + bob), (int) (w * 1.8), h + 40);
        }
        if (boss && state == 1 && cur != null) { // wind-up glow
            float pulse = 0.25f + 0.2f * (float) Math.sin(age * 0.6);
            g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, pulse * al));
            g.setColor(cur.col);
            g.fillOval((int) (x - w * 0.85), (int) (y - h - 10 + bob), (int) (w * 1.7), h + 20);
        }
        g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, al));
        g.drawImage(img, (int) dx, (int) dy, null);
        if (hurtFlash > 0) {
            g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.4f * al));
            g.drawImage(Assets.byHeight(sp, spriteH, flip, true), (int) dx, (int) dy, null);
        }
        g.setComposite(old);

        if (!boss && !dying && hp < maxHp) { // little health bar
            int bw = 46;
            int bx = (int) (x - bw / 2.0), by = (int) (y - spriteH - 10);
            g.setColor(new Color(0, 0, 0, 160));
            g.fillRect(bx - 1, by - 1, bw + 2, 6);
            g.setColor(new Color(220, 60, 60));
            g.fillRect(bx, by, (int) (bw * hp / (double) maxHp), 4);
        }
        if (!boss && behavior == B_CHARGE && state == 1) { // charge warning
            g.setColor(new Color(255, 230, 60));
            g.setFont(new Font("SansSerif", Font.BOLD, 28));
            g.drawString("!", (int) x - 5, (int) (y - spriteH - 12));
        }
    }
}
