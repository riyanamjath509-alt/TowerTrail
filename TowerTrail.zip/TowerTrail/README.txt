TOWER TRAIL - 2D Java game (Swing, no external libraries)
=========================================================

HOW TO RUN IN INTELLIJ IDEA
1. File > Open... and choose this "TowerTrail" folder.
2. Right-click the "src" folder > Mark Directory as > Sources Root.
3. File > Project Structure > set the Project SDK to JDK 8 or newer (17/21 recommended).
4. Open src/Main.java and press the green Run arrow next to main().

IMAGES
  All pictures are in  src/assets/  (inside src, so IntelliJ copies them automatically).
  If you copy only the .java files to a new project, copy the whole "assets" folder
  into your src folder too. If an image is ever missing the game now draws a built-in
  skin instead of a pink box, and prints a note in the Run console.

CONTROLS
  A / D or Left / Right ..... move
  W / Up / Space ............ jump (press again in the air = double jump)
  S + jump on a platform .... drop through it
  J (or X / Z) .............. sword slash
  K (or Shift) .............. PARRY: block hits, reflect projectiles back (3x damage), counter-hit enemies
  1 / 2 / 3 / 4 ............. skills (unlocked by beating bosses)
  P or Esc .................. pause
  Enter / Space ............. menus

STORY / PROGRESSION
  Floor 1  Iglugon  (+ Iglugat)                       -> Quick Charge        [1]
  Floor 2  BoBkuBo  (+ Ibol, Bokbol)                  -> Heavenly Fire Slash [2]
  Floor 3  Teon     (+ Bushi, Flora, Tros)            -> Solar Slash         [3]
  Floor 4  Golar    (+ Spear / Flying / Sword Golar)  -> Mighty Sword Throw  [4]
  Floor 5  Grodre   (+ Blue Eel, Snake, Lizard, Twin Eel) -> the KEY to return home

FILES
  src/Main.java       window + start
  src/GamePanel.java  game loop, menus, HUD, waves, collisions
  src/Player.java     Reto: movement, sword, 4 skills
  src/Enemy.java      minions + boss AI (each boss has its own attack list)
  src/Hazard.java     every attack / projectile / skill effect
  src/Levels.java     level names, waves, platforms, painted backgrounds
  src/Assets.java     image loading     src/Sfx.java  generated sound effects
  src/assets/         sprites cut from your character sheets + title.jpg
  src/Fallback.java   built-in drawn skins used if an image is missing

TWEAKING (easy numbers to change)
  Player.java  -> maxHp, MOVE, MAXCD (skill cooldowns), damage values in cast()
  Enemy.java   -> boss()/minion() : hp, speed, contactDmg, attack lists
  Levels.java  -> WAVES (which minions come before each boss)
